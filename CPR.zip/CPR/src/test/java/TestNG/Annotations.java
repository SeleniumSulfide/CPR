package TestNG;

//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeTest;
//import org.testng.annotations.BeforeMethod;
//import org.testng.annotations.Test;
import org.testng.annotations.*;
//import org.testng.annotations.

public class Annotations {
	
	@BeforeTest //Runs before each Test
	public void BeforeTest()
	{
		System.out.println("Before Test");
	}
	
	@AfterTest //Runs after each Test
	public void AfterTest()
	{
		System.out.println("AfterTest");
	}
		
	@BeforeMethod // Runs before each method "@Test"
	// Needs defined with each @Test it effects
	public void BeforeMethod()
	{
		System.out.println("Before Method");
	}
	
	@AfterMethod // Runs after each method "@Test"
	// Needs defined with each @Test it effects
	public void AfterMethod()
	{
		System.out.println("AfterMethod");
	}
	

	public static String test()
	{
		return "test-method";
		
	}
	
}
