package TestNG;

import org.testng.annotations.*;

import util.Data.MSSQL;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.openqa.selenium.ie.*;

public class TestCases {
	
	@DataProvider //expects 2d array
	public Object[][] getData()
	{
		
		int x = 3;		//x = number of times the tC should run
		int y = 2;		//y = number of parameters should be sent for each run
		Object[][] data = new Object[x][y];
		
		data[0][0] = "User1";
		data[0][1] = "Pass1";
		
		data[1][0] = "User2";
		data[1][1] = "Pass2";
		
		data[2][0] = "User3";
		data[2][1] = "Pass3";
		
		return data;
	}

	@Test(dataProvider="getData",groups={"Priority1","BobSaget"},enabled=false) 
	public void OpeningBrowser(String username, String password)
	{
		//getData is the name of the function to run to Provide Data, getData has to give parameters that match input variables
		//groups are a way of grouping test cases, comma delimited {"Group","Group"}
		System.out.println("test1");
		System.out.println("User="+username);
		System.out.println("Password="+password);
		System.out.println(Annotations.test());
		
		System.setProperty("webdriver.ie.driver", "C:\\eclipse\\Selenium\\IEDriver\\x64\\IEDriverServer.exe");
		InternetExplorerDriver driver = new InternetExplorerDriver();
		driver.get("http://www.google.com");
		System.out.println(driver.toString());
		driver.close();
		driver.quit();
	}
	
	@Test(dependsOnMethods={"OpeningBrowser"},groups= {"Priority2","BobSaget"},enabled=false)
	public void First()
	{
		//DependsOnMethods - List of methods that must pass successfully for this to execute
		//alwaysRun - Run regardless of DependsOnMethods executions status
		System.out.println("test2");
		System.out.println(Annotations.test());
	}
	
	@Test(timeOut=5000,groups={"Priority1","BobSaget"},enabled=false)
	//@Parameters({"UserID","Password"}) //Looks in XML for the values specified by "Name"
	public void TimeOut()
	{
		//timeOut - amount of time in ms test should take to execute, otherwise fail
		//System.out.println("User="+username);
		//System.out.println("Password="+password);
	}
	
	@Test(enabled=true)
	public void DisabledTC()
	{
		
		MSSQL sql = new MSSQL("wdv-bizappsql3","CapitalStockINT",1583);
		sql.Connect();
		
		
		try {
			ResultSet rs = sql.ExecuteSQL("Select SP.* from dbo.StockProfile SP inner join IfsBusinessPartner IFS on IFS.BusinessPartnerID = SP.BusinessPartnerID "
											+"where BP_ID = 100171 "
											+"and CreateDateTime = (select max(CreateDateTime) MaxTime from StockProfile SP2 where SP.BusinessPartnerId = SP2.BusinessPartnerID)");
			ResultSetMetaData meta;
			meta = rs.getMetaData();
			int colCount = meta.getColumnCount();
			while (rs.next())
			{
			    for (int col=1; col <= colCount; col++) 
			    {
			        Object value = rs.getObject(col);
			        if (value != null) 
			        {
			            System.out.println(value.toString());
			        }
			    }
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
	}
}
