package TestNG;
import org.testng.annotations.*;

public class Annot2 {
	@BeforeSuite
	public void BeforeSuite()
	{
		System.out.println("Before Suite");
	}

	@AfterSuite
	public void AfterSuite()
	{
		System.out.println("After Suite");
	}
}
