package CapStock;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import junit.framework.Assert;
import util.ExtendedControls.ReportConfigurator;
import util.ExtendedControls.SelectAShareholder;

public class HeaderTest 
{
	public InternetExplorerDriver driver;
	public Header header;
	public App app;
	public SelectAShareholder selectAShareholder;
	public ReportConfigurator reportConfigurator;
	String URL;
	
	@BeforeTest(groups={"Basic","Navigation","Menu","MenuHome","MenuReports","MenuAdministration","MenuTransactions"})
	@Parameters({"URL"})
	public void OpenBrowser(String URL)
	{
		System.setProperty("webdriver.ie.driver", "C:\\eclipse\\Selenium\\IEDriver\\x86\\IEDriverServer.exe");
		this.driver = new InternetExplorerDriver();
		this.URL = URL;
		driver.get(this.URL);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		header = new Header(driver);
		app = new App(driver);
		selectAShareholder = new SelectAShareholder(driver);
		reportConfigurator = new ReportConfigurator(driver);
	}
	
	@AfterTest(groups={"Basic","Navigation","MenuHome","MenuReports","MenuAdministration","MenuTransactions"})
	public void CloseBrowser()
	{
		this.driver.close();
		try {
			Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@AfterMethod(groups={"Basic","Navigation","Menu","MenuHome","MenuReports","MenuAdministration","MenuTransactions"})
	public void GoHome()
	{
		header.navBar.Home.Click();
		new Home(driver).Search.waitTillExists();
	}
	
	
	@Test(enabled=true,
			groups={"Basic","Navigation","Menu","MenuHome"})
	public void ClickHome()
	{
		header.navBar.Home.Click();
		Assert.assertEquals("MemberSearch", driver.getCurrentUrl().split("/")[3]);
	}
	
	public class Menu_Reports
	{
		@AfterMethod(groups={"Basic","Navigation","Menu","MenuReports"})
		public void GoHome()
		{
			header.navBar.Home.Click();
			new Home(driver).Search.waitTillExists();
		}
		
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"})	
		public void ClickReports()
		{
			header.navBar.Reports.Click();
			app.Sleep();
			Assert.assertEquals("Reports", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickOutstandingRedemptionsReport()
		{
			header.navBar.reportsMenu.ClickOutstandingRedemptionsReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Outstanding Redemptions Report", reportname);
			
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockNegativeExcessReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockNegativeExcessReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Negative Excess Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockTransactionsReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockTransactionsReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Transactions Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockTransactionsActivityReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockTransactionsActivityReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Transactions Activity Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockJournalEntriesReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockJournalEntriesReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Journal Entries Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockTransactionsByMemberReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockTransactionsByMemberReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Transactions By Member Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockBalanceReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockBalanceReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Balance Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockBalanceDetailsReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockBalanceDetailsReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Balance Details Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockDividendsReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockDividendsReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Dividends Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockTransactionHistory()
		{
			header.navBar.reportsMenu.ClickCapitalStockTransactionHistory();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Transaction History", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickVotingSharesReport()
		{
			header.navBar.reportsMenu.ClickVotingSharesReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Voting Shares Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickStockPercentageReport()
		{
			header.navBar.reportsMenu.ClickStockPercentageReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Stock Percentage Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockProfileActivityReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockProfileActivityReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Profile Activity Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockTrialBalance()
		{
			header.navBar.reportsMenu.ClickCapitalStockTrialBalance();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Trial Balance", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockActivityRollforwardReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockActivityRollforwardReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Activity Rollforward Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption()
		{
			header.navBar.reportsMenu.ClickCapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Trial Balance- Member Concentration and Excess Stock Subject to Redemption", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickFAS150InterestExpenseReport()
		{
			header.navBar.reportsMenu.ClickFAS150InterestExpenseReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("FAS150 Interest Expense Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickAMADetails()
		{
			header.navBar.reportsMenu.ClickAMADetails();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("AMA Details", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickAMAToday()
		{
			header.navBar.reportsMenu.ClickAMAToday();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("AMA Today", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickMemberDividendHistoryReport()
		{
			header.navBar.reportsMenu.ClickMemberDividendHistoryReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Member Dividend History Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickPendingTransactionsReport()
		{
			header.navBar.reportsMenu.ClickPendingTransactionsReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Pending Transactions Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCreditProductsDetail()
		{
			header.navBar.reportsMenu.ClickCreditProductsDetail();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Credit Products Detail", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockBackdatedTransactionReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockBackdatedTransactionReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock Backdated Transaction Report", reportname);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuReports"},
				dependsOnMethods={"ClickReports"})
		public void ClickCapitalStockAllShareholderSharesReport()
		{
			header.navBar.reportsMenu.ClickCapitalStockAllShareholderSharesReport();
			reportConfigurator.ReportLabel.waitTillExists();
			String reportname = reportConfigurator.ReportLabel.GetText();
			reportConfigurator.Cancel.Click();
			Assert.assertEquals("Capital Stock All Shareholder Shares Report", reportname);
		}
	}
	
	public class Menu_Administration
	{
		@AfterMethod(groups={"Basic","Navigation","Menu","MenuAdministration"})
		public void GoHome()
		{
			header.navBar.Home.Click();
			new Home(driver).Search.waitTillExists();
		}
		
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"})
		public void ClickAdministration()
		{
			header.navBar.Administration.Click();
			app.Sleep();
			Assert.assertEquals("Admin", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickGlobalSettings() 
		{ 
			 header.navBar.administrationMenu.ClickGlobalSettings();
			app.Sleep();
			Assert.assertEquals("Global", driver.getCurrentUrl().split("/")[4]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickStockTransactionBlackout()
		{ 
			header.navBar.administrationMenu.ClickStockTransactionBlackout();
			app.Sleep();
			Assert.assertEquals("BlackoutPeriodEdit", driver.getCurrentUrl().split("/")[4]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickStockRequirementSettings()
		{ 
			header.navBar.administrationMenu.ClickStockRequirementSettings();
			app.Sleep();
			Assert.assertEquals("StockRequirementSettings", driver.getCurrentUrl().split("/")[4]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickTransactionDenialPeriods()
		{ 
			header.navBar.administrationMenu.ClickTransactionDenialPeriods();
			app.Sleep();
			Assert.assertEquals("DenialPeriod", driver.getCurrentUrl().split("/")[4]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickAccountingAdministration()
		{ 
			header.navBar.administrationMenu.ClickAccountingAdministration();
			app.Sleep();
			Assert.assertEquals("Accounting", driver.getCurrentUrl().split("/")[4]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickClassAStockSettings()
		{ 
			header.navBar.administrationMenu.ClickClassAStockSettings();
			app.Sleep();
			Assert.assertEquals("ClassAStockSettings", driver.getCurrentUrl().split("/")[4]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuAdministration"},
				dependsOnMethods={"ClickAdministration"})
		public void ClickTotalAssetsLoadSetup()
		{
			header.navBar.administrationMenu.ClickTotalAssetsLoadSetup();
			app.Sleep();
			Assert.assertEquals("AnnualTotalAssetsLoad", driver.getCurrentUrl().split("/")[4]);
		}
	}
	
	public class Menu_Transactions
	{
		@AfterMethod(groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void GoHome()
		{
			header.navBar.Home.Click();
			new Home(driver).Search.waitTillExists();
		}
		
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickPurchase()
		{
			header.navBar.transactionMenu.ClickPurchase();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("purchase", driver.getCurrentUrl().split("#")[1]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickRepurchase()
		{
			header.navBar.transactionMenu.ClickRepurchase();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("repurchase", driver.getCurrentUrl().split("#")[1]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickRedemption()
		{
			header.navBar.transactionMenu.ClickRedemption();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("redemption", driver.getCurrentUrl().split("#")[1]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickCancellation()
		{
			header.navBar.transactionMenu.ClickCancellation();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("cancellation", driver.getCurrentUrl().split("#")[1]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickStockConversion()
		{
			header.navBar.transactionMenu.ClickStockConversion();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("conversion", driver.getCurrentUrl().split("#")[1]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickDividendProjection()
		{
			header.navBar.transactionMenu.ClickDividendProjection();
			app.Sleep();
			Assert.assertEquals("DividendProjection", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickTransfer()
		{
			header.navBar.transactionMenu.ClickTransfer();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("StockTransfer", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickMerger()
		{
			header.navBar.transactionMenu.ClickMerger();
			app.Sleep();
			if (selectAShareholder.CancelButton.waitTillExists())
			{
				selectAShareholder.CancelButton.Click();
			}
			else
			{
				Assert.fail("Cancel button not found.");
			}
			Assert.assertEquals("StockMerger", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickTransactionMaintenance()
		{
			header.navBar.transactionMenu.ClickTransactionMaintenance();
			app.Sleep();
			Assert.assertEquals("TransactionMaintenance", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickTransactionBackdating()
		{
			header.navBar.transactionMenu.ClickTransactionBackdating();
			app.Sleep();
			Assert.assertEquals("TransactionBackdating", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickTransactionApproval()
		{
			header.navBar.transactionMenu.ClickTransactionApproval();
			app.Sleep();
			Assert.assertEquals("TransactionApproval", driver.getCurrentUrl().split("/")[3]);
		}
		
		@Test(enabled=true,
				groups={"Basic","Navigation","Menu","MenuTransactions"})
		public void ClickMassRepurchase()
		{
			header.navBar.transactionMenu.ClickMassRepurchase();
			app.Sleep();
			Assert.assertEquals("MassStockRepurchase", driver.getCurrentUrl().split("/")[3]);
		}
	}
}
