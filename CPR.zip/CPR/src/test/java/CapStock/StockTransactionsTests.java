package CapStock;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import util.Data.MSSQL;

public class StockTransactionsTests 
{
	public InternetExplorerDriver driver;
	public Home home;
	public StockTransactions stockTransactions;
	public App app;
	public MSSQL sql;
	
	@BeforeTest(enabled=true,
					groups={"Basic","Navigation","Transactions"})
	@Parameters({"URL"})
	public void OpenBrowser(String URL)
	{
		System.setProperty("webdriver.ie.driver", "C:\\eclipse\\Selenium\\IEDriver\\x86\\IEDriverServer.exe");		
		this.driver = new InternetExplorerDriver();
		driver.get(URL);		
		
		home = new Home(driver);
		app = new App(driver);
		
		sql = new MSSQL("wdv-bizappsql3","CapitalStockINT",1583);
		sql.Connect();
	}

	@Test(enabled=true,
			groups={"Basic","Navigation","Transactions"})
	public void ValidateStockProfile()
	{
		int BPID = 100171;
		home.SearchForMember(BPID);
		home.ResultsGrid.checkResultExists(BPID);
		home.NavigatePurchase(BPID);
		
		app.Sleep();
		
		stockTransactions = new StockTransactions(this.driver, sql);
		stockTransactions.Purchase.waitTillExists();
		assert stockTransactions.StockProfile.ValidateStockProfile(BPID);
	}
}
