package CapStock;

import java.io.IOException;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import CapStock.Home;
import util.Data.MSSQL;

public class HomeTest 
{
	public InternetExplorerDriver driver;
	public Home home;
	public App app;
	public MSSQL sql;
	
	@BeforeTest(enabled=true,
					groups={"Basic","Navigation","MemberSearch"})
	@Parameters({"URL"})
	public void OpenBrowser(String URL)
	{
		System.setProperty("webdriver.ie.driver", "C:\\eclipse\\Selenium\\IEDriver\\x86\\IEDriverServer.exe");
		this.driver = new InternetExplorerDriver();
		driver.get(URL);		
		
		home = new Home(driver);
		app = new App(driver);
		
		sql = new MSSQL("wdv-bizappsql3","CapitalStockINT",1583);
		sql.Connect();
	}
	
	@AfterTest(enabled=true,
					groups={"Basic","Navigation","MemberSearch"})
	public void CloseBrowser()
	{
		this.driver.close();
		try {
			Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@AfterMethod(enabled=true,
					groups={"Basic","Navigation","MemberSearch"})
	public void GoHome()
	{
		home.header.navBar.Home.Click();
		home.Search.waitTillExists();
		home.SearchCriteria.waitTillExists();
	}
	
	
	@Test(enabled=true,
				groups={"Basic","Navigation","MemberSearch"})
	public void SearchForMember()
	{
		int BPID = 100171;
		
		if(!home.SearchCriteria.waitTillExists()) { Assert.fail("SearchCriteria was not found in time"); }
		
		home.SearchForMember(BPID);
		
		if (!home.ResultsGrid.checkResultExists(BPID)) { Assert.fail("BPID [BPID] not found.".replace("[BPID]", String.valueOf(BPID))); }
		
		home.SearchForMember("Flag");
		
		if (!home.ResultsGrid.checkResultExists(BPID)) { Assert.fail("BPID [BPID] not found.".replace("[BPID]", String.valueOf(BPID))); }
	}
	
	@Test(enabled=true,
			groups={"Basic","Navigation","MemberSearch"},
			dependsOnMethods={"SearchForMember"})
	public void NavigateToPurchase()
	{
		int BPID = 100171;
		home.SearchForMember(BPID);
		home.ResultsGrid.checkResultExists(BPID);
		home.NavigatePurchase(BPID);
		new StockTransactions(this.driver, sql).Purchase.waitTillExists();
		Assert.assertEquals("purchase", driver.getCurrentUrl().split("#")[1]);
	}
	
	@Test(enabled=true,
			groups={"Basic","Navigation","MemberSearch"},
			dependsOnMethods={"SearchForMember"})
	public void NavigateToRepurchase()
	{
		int BPID = 100171;
		home.SearchForMember(BPID);
		home.ResultsGrid.checkResultExists(BPID);
		home.NavigateRepurchase(BPID);
		new StockTransactions(this.driver, sql).Purchase.waitTillExists();
		Assert.assertEquals("repurchase", driver.getCurrentUrl().split("#")[1]);
	}
	
	@Test(enabled=true,
			groups={"Basic","Navigation","MemberSearch"},
			dependsOnMethods={"SearchForMember"})
	public void NavigateToRedemption()
	{
		int BPID = 100171;
		home.SearchForMember(BPID);
		home.ResultsGrid.checkResultExists(BPID);
		home.NavigateRedemption(BPID);
		new StockTransactions(this.driver, sql).Purchase.waitTillExists();
		Assert.assertEquals("redemption", driver.getCurrentUrl().split("#")[1]);
	}
	
	@Test(enabled=true,
			groups={"Basic","Navigation","MemberSearch"},
			dependsOnMethods={"SearchForMember"})
	public void NavigateToCancellation()
	{
		int BPID = 100171;
		home.SearchForMember(BPID);
		home.ResultsGrid.checkResultExists(BPID);
		home.NavigateCancellation(BPID);
		new StockTransactions(this.driver, sql).Purchase.waitTillExists();
		Assert.assertEquals("cancellation", driver.getCurrentUrl().split("#")[1]);
	}
	
	@Test(enabled=true,
			groups={"Basic","Navigation","MemberSearch"},
			dependsOnMethods={"SearchForMember"})
	public void NavigateToStockConversion()
	{
		int BPID = 100171;
		home.SearchForMember(BPID);
		home.ResultsGrid.checkResultExists(BPID);
		home.NavigateStockConversion(BPID);
		new StockTransactions(this.driver, sql).Purchase.waitTillExists();
		Assert.assertEquals("conversion", driver.getCurrentUrl().split("#")[1]);
	}
}
