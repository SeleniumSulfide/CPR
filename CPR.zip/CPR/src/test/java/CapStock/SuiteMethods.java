package CapStock;

public class SuiteMethods 
{

}
