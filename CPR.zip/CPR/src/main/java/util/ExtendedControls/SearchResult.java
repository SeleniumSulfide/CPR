package util.ExtendedControls;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseControls.Button;
import util.BaseControls.DropDown;
import util.BaseControls.Link;

public class SearchResult 
{
	WebDriver driver;
	
	public SearchResultBy by = new SearchResultBy();
	
	public Link Name;
	public String CityState;
	public int BPID;
	public String Type;
	public TransactionType TransactionType;
	public Button EnterTransaction;
	
	public class TransactionType extends DropDown
	{
		public TransactionType(WebElement element, By by, WebDriver driver) { super(element, driver, by); }
		
		public void SetDefault() { SetByVisibleText("Select Transaction...");	}
		
		public void SetPurchase() { SetByVisibleText("Purchase");	}
		
		public void SetRepurchase() { SetByVisibleText("Repurchase"); }
		
		public void SetRedemption() { SetByVisibleText("Redemption"); }
		
		public void SetCancellation() { SetByVisibleText("Cancellation"); }
		
		public void SetStockConversion() { SetByVisibleText("Stock Conversion"); }
	}
	
	public SearchResult(WebElement row, WebDriver driver)
	{
		this.driver = driver;
		Name = new Link(row, this.driver, by.Name);
		CityState = row.findElement(by.CityState).getText();
		BPID = Integer.parseInt(row.findElement(by.BPID).getText());
		Type = row.findElement(by.Type).getText();
		TransactionType = new TransactionType(row, by.TransacitonType, this.driver);
		EnterTransaction = new Button(row, this.driver, by.EnterTransaction);
	}
}
