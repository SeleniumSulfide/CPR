package util.ExtendedControls;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.Label;
import util.BaseControls.TextBox;

public class SelectAShareholder
{
	WebDriver driver;
	public SelectAShareholderBy by = new SelectAShareholderBy();
	public TextBox SearchCriteria;
	public Button SearchButton;
	public Button SelectButton;
	public Button CancelButton;
	public Label TargetBP;	
	
	public SelectAShareholder(WebDriver driver) 
	{ 
		this.driver = driver;
		SearchCriteria = new TextBox(this.driver, by.SearchCriteria);
		SearchButton = new Button(this.driver, by.SearchButton);
		SelectButton = new Button(this.driver, by.SelectButton);
		CancelButton = new Button(this.driver, by.CancelButton);
	}
	
	public void setTargetBP(String BPID)
	{
		by.TargetBP = By.xpath("//span[contains(text(),'[BPID]')]".replace("[BPID]", BPID));
		TargetBP = new Label(driver, by.TargetBP);
	}
}