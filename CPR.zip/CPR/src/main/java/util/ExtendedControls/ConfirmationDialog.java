package util.ExtendedControls;

import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.Label;

public class ConfirmationDialog 
{
	WebDriver driver;
	
	public ConfirmationDialogBy by = new ConfirmationDialogBy();
	
	public Label Title;
	public Label Message;
	public Button Yes;
	public Button No;
	
	
	public ConfirmationDialog(WebDriver driver)
	{
		this.driver = driver;
		ReInitControls();
	}
	
	public void ReInitControls()
	{
		Title = new Label(driver, by.Title);
		Message = new Label(driver, by.Message);
		Yes = new Button(driver, by.Yes);
		No = new Button(driver, by.No);
	}
}
