package util.ExtendedControls;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.DropDown;

public class DateControl 
{
	WebDriver driver;
	
	public DateControlBy by = new DateControlBy();
	
	Format monthFormat = new SimpleDateFormat("MMM");
	Format dayFormat = new SimpleDateFormat("d");
	Format yearFormat = new SimpleDateFormat("YYYY");
	
	String MonthDefault = monthFormat.format(new Date());
	String DayDefault = dayFormat.format(new Date());
	String YearDefault = yearFormat.format(new Date());
	
	public Button Prev;
	public Button Next;
	public Button Day;
	
	public Month Month;
	public Year Year;
	
	public DateControl(WebDriver driver) 
	{ 
		this.driver = driver;
		Prev = new Button(this.driver, by.Prev);
		Next = new Button(this.driver, by.Next);
		Day = new Button(this.driver, by.Day);
		Month = new Month(this.driver, by.Month);
		Year = new Year(this.driver, by.Year);
		
		String xpath = "//a[text()='[DAY]']".replace("[DAY]", DayDefault);
		by.Day = By.xpath(xpath);
	}
	
	public class Month extends DropDown
	{	
		public Month(WebDriver driver, By by) { super(driver, by); }
		
		public void SetDefault() { SetByVisibleText(MonthDefault); }
	}
	
	public class Year extends DropDown
	{
		public Year(WebDriver driver, By by) { super(driver, by); }
		
		public void SetDefault() { SetByVisibleText(YearDefault); }
	}
	
	public void SetDayButton(String day)
	{
		String xpath = "//a[text()='[DAY]']".replace("[DAY]", day);
		by.Day = By.xpath(xpath);
		Day = new Button(driver, by.Day);
	}
	
	public void SetDate(Date date)
	{
		Month.SetByVisibleText(monthFormat.format(date));
		Year.SetByVisibleText(yearFormat.format(date));
		
		SetDayButton(dayFormat.format(date));
		Day.Click();
	}
}
