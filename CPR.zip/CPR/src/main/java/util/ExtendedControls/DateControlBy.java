package util.ExtendedControls;

import org.openqa.selenium.By;

public class DateControlBy 
{
	public By Prev = By.xpath("//a[@class[contains(.,'ui-datepicker-prev')]]");
	public By Next = By.xpath("//a[@class[contains(.,'ui-datepicker-prev')]]");
	public By Day;
	public By Month = By.xpath("//select[@data-handler='selectMonth')]");
	public By Year = By.xpath("//select[@data-handler='selectYear']");
}
