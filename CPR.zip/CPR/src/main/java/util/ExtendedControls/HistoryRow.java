package util.ExtendedControls;

import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import CapStock.App;

public class HistoryRow 
{
	WebDriver driver;
	
	public HistoryRowBy by = new HistoryRowBy();
	App app;
	
	public Date date;
	public String Description;
	public String UserId;
	public Boolean Found = true;
	
	public HistoryRow(WebElement row, WebDriver driver)
	{
		this.driver = driver;
		app = new App(this.driver);
		
		if (row.findElement(by.Date).getText() != "No rows Found.")
		{
			date = app.parseDate(row.findElement(by.Date).getText(), "MM/dd/yyyy");
			Description = row.findElement(by.Description).getText();
			UserId = row.findElement(by.UserID).getText();
		}
		else
		{
			Found = false;
		}
	}
}
