package util.ExtendedControls;

import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.Label;

public class MessageDialog 
{
	WebDriver driver;
	public MessageDialogBy by = new MessageDialogBy();
	public Label Title;
	public Button OK;
	public Label Message;
	
	public MessageDialog(WebDriver driver)
	{	
		this.driver = driver;
		ReInitControls();
	}
	
	public void ReInitControls()
	{
		Title = new Label(driver, by.Title);
		OK = new Button(driver, by.OK);
		Message = new Label(driver, by.Message);
	}
}
