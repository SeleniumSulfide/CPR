package util.ExtendedControls;

import org.openqa.selenium.By;

public class ReportConfiguratorBy 
{
	public By ReportLabel = By.id("reportLabel");
	
	public class SearchUsing
	{
		public By All = By.id("SearchUsing1");
		public By One = By.id("SearchUsing2");
		public By BPID = By.id("BPIDSelect");
		public By SelectShareholder = By.id("reportsMemberSelect");
	}
	public SearchUsing SearchUsing = new SearchUsing();
	
	public By AsOfDate = By.id("AsOfDate");
	public By AsOfDateButton = By.xpath("//input[@id='AsOfDate']/following-sibling::img");
	
	public By StartDate = By.id("StartDate");
	public By StartDateButton = By.xpath("//input[@id='StartDate']/following-sibling::img");
	
	public By EndDate = By.id("EndDate");
	public By EndDateButton = By.xpath("//input[@id='EndDate']/following-sibling::img");
	
	public By DividendPeriodEndDate = By.id("DividendPeriodEndDate");
	public By DividendPeriodEndDateButton = By.xpath("//input[@id='DividendPeriodEndDate']/following-sibling::img");
	
	public By RequestedDate = By.id("RequestedDate");
	public By RequestedDateButton = By.xpath("//input[@id='RequestedDate']/following-sibling::img");
	
	public By ApprovedDate = By.id("ApproveDate");
	public By ApprovedDateButton = By.xpath("//input[@id='ApproveDate']/following-sibling::img");
	
	public By BPID = By.id("BPID");
	public By SelectShareholder = By.id("reportsMember");
	
	public By RulePercentage = By.id("percent");
	
	public By EffectiveDate = By.id("EffectiveDate");
	public By EffectiveDateButton = By.xpath("//input[@id='EffectiveDate']/following-sibling::img");
	
	public class TransactionType
	{
		public By SortByType = By.id("TransactionTypeRadio1");
		public By LimitTo = By.id("TransactionTypeRadio2");
		public By TransactionType = By.id("TransactionType");
	}
	public TransactionType TransactionType = new TransactionType();
	
	public By MultiTransactionType = By.id("MultipleTransactionType");
	
	public By DividendPeriod = By.id("DividendPeriod");
	public By DividendPeriodButton = By.xpath("//input[@id='DividendPeriod']/following-sibling::img");
	
	public By YearEnd = By.id("YearEnd");
	
	public By ActivityAsOfDate = By.id("ActivityAsOfDate");
	public By ActivityAsOfDateButton = By.xpath("//input[@id='ActivityAsOfDate']/following-sibling::img");
	
	public By MRAEffectiveDate = By.id("MRAAsOfDate");
	public By MRAEffectiveDateButton = By.xpath("//input[@id='MRAAsOfDate']/following-sibling::img");
	
	public By Format = By.id("Format");
	
	public By RenderReport = By.xpath("//button[contains(.,'Render Report')]");
	public By Cancel = By.xpath("//button[contains(.,'Cancel')]");
	
	public By ErrorMessages = By.xpath("#errorContainer > ul:nth-child(1) > li");
}
