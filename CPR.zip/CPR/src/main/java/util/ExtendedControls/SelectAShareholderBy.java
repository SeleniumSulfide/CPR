package util.ExtendedControls;

import org.openqa.selenium.By;

public class SelectAShareholderBy 
{
	public By SearchCriteria = By.xpath("//*[@id='SearchTerm']");
	public By SearchButton = By.xpath("//*[@id='btnSearchMembers']");
	public By SelectButton = By.xpath("//button[contains(.,'Select')]");
	public By CancelButtonXpath = By.xpath("//button[contains(.,'Cancel')]");
	public By TargetBP;
	
	public By CancelButton = By.cssSelector("button.ui-button:nth-child(2)");
}
