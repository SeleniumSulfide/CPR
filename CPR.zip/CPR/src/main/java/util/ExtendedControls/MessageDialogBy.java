package util.ExtendedControls;

import org.openqa.selenium.By;

public class MessageDialogBy 
{
	public By Title = By.xpath("//span[@id='ui-dialog-title-dialogAlert'])");
	public By OK = By.xpath("//button[contains(.,'OK')]");
	public By Message = By.xpath("//section[ancestor::div[@id='dialogAlert']]");
}
