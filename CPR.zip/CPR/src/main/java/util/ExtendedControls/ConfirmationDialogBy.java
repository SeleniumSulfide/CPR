package util.ExtendedControls;

import org.openqa.selenium.By;

public class ConfirmationDialogBy 
{
	public By Title = By.xpath("//*[@id='ui-dialog-title-dialogConfirmation']");
	public By Message = By.xpath("//*[@id='dialogConfirmation']");
	public By Yes = By.xpath("//button[contains(.,'Yes')]");
	public By No = By.xpath("//button[contains(.,'No')]");	
}
