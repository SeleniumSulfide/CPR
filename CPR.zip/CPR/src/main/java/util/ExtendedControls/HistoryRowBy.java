package util.ExtendedControls;

import org.openqa.selenium.By;

public class HistoryRowBy 
{
	public By Date = By.xpath(".//td[1]");
	public By Description = By.xpath(".//td[2]");
	public By UserID = By.xpath(".//td[3]");
}
