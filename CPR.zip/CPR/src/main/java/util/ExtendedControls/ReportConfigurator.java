package util.ExtendedControls;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.DropDown;
import util.BaseControls.ErrorMessages;
import util.BaseControls.Label;
import util.BaseControls.TextBox;

public class ReportConfigurator 
{
	WebDriver driver;
	public ReportConfiguratorBy by = new ReportConfiguratorBy();
	
	public Label ReportLabel;
	
	public class SearchUsing
	{
		public WebDriver driver;
		
		public Button All;
		public Button One;
		public TextBox BPID;
		public Button SelectShareholder;
		
		public SearchUsing(WebDriver driver)
		{
			this.driver = driver;
			All = new Button(this.driver, by.SearchUsing.All);
			One = new Button(this.driver, by.SearchUsing.One);
			BPID = new TextBox(this.driver, by.SearchUsing.BPID);
			SelectShareholder = new Button(this.driver, by.SearchUsing.SelectShareholder);
		}
	}
	public SearchUsing searchUsing;
	
	public TextBox StartDate; 
	public Button StartDateButton;
	
	public TextBox EndDate; 
	public Button EndDateButton;
	
	public TextBox AsOfDate;
	public Button AsOfDateButton;
	
	public TextBox DividendPeriodEndDate;
	public Button DividendPeriodEndDateButton;
	
	public TextBox RequestedDate;
	public Button RequestedDateButton;
	
	public TextBox ApprovedDate;
	public Button ApprovedDateButton;
	
	public TextBox BPID;
	public Button SelectShareholder;
	
	public TextBox RulePercentage;
	
	public TextBox EffectiveDate;
	public Button EffectiveDateButton;
	
	public class TransactionSelector extends DropDown
	{
		public TransactionSelector(WebDriver driver, By by)
		{
			super(driver, by);
		}
		
		public void SetDefault() { SetByVisibleText("Select..."); }
		public void SetStockMergerwithMember() { SetByVisibleText("Stock Merger with Member"); }
		public void SetStockMergerwithNonMember() { SetByVisibleText("Stock Merger with Non-Member"); }
		public void SetStockMergerwithReceiverFDIC() { SetByVisibleText("Stock Merger with Receiver(FDIC)"); }
		public void SetOriginalStockIssuance() { SetByVisibleText("Original Stock Issuance"); }
		public void SetRequiredStockPurchase() { SetByVisibleText("Required Stock Purchase"); }
		public void SetVoluntaryStockPurchase() { SetByVisibleText("Voluntary Stock Purchase"); }
		public void SetStockDividendPayment() { SetByVisibleText("Stock Dividend Payment"); }
		public void SetCashDividendPayment() { SetByVisibleText("Cash Dividend Payment"); }
		public void SetCancelRedemptionRequest() { SetByVisibleText("Cancel Redemption Request"); }
		public void SetStockRedemption() { SetByVisibleText("Stock Redemption"); }
		public void SetStockRedesignation() { SetByVisibleText("Stock Redesignation"); }
		public void SetB2StockIssue() { SetByVisibleText("B2 Stock Issue"); }
		public void SetCancelRepurchaseRequest() { SetByVisibleText("Cancel Repurchase Request"); }
		public void SetRejectedRepurchase() { SetByVisibleText("Rejected Repurchase"); }
		public void SetRepurchaseofStockDividend() { SetByVisibleText("Repurchase of Stock Dividend"); }
		public void SetRepurchaseofExcessStockInitiatedbyFHLBI() { SetByVisibleText("Repurchase of Excess Stock Initiated by FHLBI"); }
		public void SetRepurchaseofExcessStockInitiatedbyMember() { SetByVisibleText("Repurchase of Excess Stock Initiated by Member"); }
		public void SetCancelWithdrawalRequest() { SetByVisibleText("Cancel Withdrawal Request"); }
		public void SetRelocation() { SetByVisibleText("Relocation"); }
		public void SetTerminationofMembership() { SetByVisibleText("Termination of Membership"); }
		public void SetStockTransfer() { SetByVisibleText("Stock Transfer"); }
		public void SetWithdrawalfromMembership() { SetByVisibleText("Withdrawal from Membership"); }
		public void SetCancellationFeeManualEntry() { SetByVisibleText("Cancellation Fee Manual Entry"); }

	}
	
	public class TransactionType
	{
		WebDriver driver;
		public Button SortByType;
		public Button LimitTo;
		public TransactionSelector transactionType;
		
		public TransactionType(WebDriver driver)
		{
			this.driver = driver;
			SortByType = new Button(this.driver, by.TransactionType.SortByType);
			LimitTo = new Button(this.driver, by.TransactionType.LimitTo);
			transactionType = new TransactionSelector(driver, by.TransactionType.TransactionType);
		}
	}
	public TransactionType transactionType;
	
	public TransactionSelector multiTransactionType;
	
	public TextBox DividendPeriod;
	public Button DividendPeriodButton;
	
	public DropDown YearEnd;
	
	public TextBox ActivityAsOfDate;
	public Button ActivityAsOfDateButton;
	
	public TextBox MRAEffectiveDate;
	public Button MRAEffectiveDateButton;
	
	public class Format extends DropDown
	{
		public Format(WebDriver driver, By by)
		{
			super(driver, by);
		}
		
		public void SetCrystalReport() { SetByVisibleText("Crystal Report Viewer"); }
		public void SetAdobePDF() { SetByVisibleText("Adobe PDF"); }
		public void SetExcel() { SetByVisibleText("Excel"); }
		public void SetWord() { SetByVisibleText("Word"); }
	}
	public Format format;
	
	public Button RenderReport;
	public Button Cancel;
	
	
	public DateControl DateControl;
	public SelectAShareholder SelectAShareholder;
	
	public ErrorMessages ErrorMessages;
	
	public ReportConfigurator(WebDriver driver)
	{
		this.driver = driver;
		ReportLabel = new Label(this.driver, by.ReportLabel);
		searchUsing = new SearchUsing(this.driver);
		StartDate = new TextBox(this.driver, by.StartDate);
		StartDateButton = new Button(this.driver, by.StartDateButton);
		EndDate = new TextBox(this.driver, by.EndDate);
		EndDateButton = new Button(this.driver, by.EndDateButton);
		AsOfDate = new TextBox(this.driver, by.AsOfDate);
		AsOfDateButton = new Button(this.driver, by.AsOfDateButton);
		DividendPeriodEndDate = new TextBox(this.driver, by.DividendPeriodEndDate);
		DividendPeriodEndDateButton = new Button(this.driver, by.DividendPeriodEndDateButton);
		RequestedDate = new TextBox(this.driver, by.RequestedDate);
		RequestedDateButton = new Button(this.driver, by.RequestedDateButton);
		ApprovedDate = new TextBox(this.driver, by.ApprovedDate);
		ApprovedDateButton = new Button(this.driver, by.ApprovedDateButton);
		BPID = new TextBox(this.driver, by.BPID);
		SelectShareholder = new Button(this.driver, by.SelectShareholder);
		RulePercentage = new TextBox(this.driver, by.RulePercentage);
		EffectiveDate = new TextBox(this.driver, by.EffectiveDate);
		EffectiveDateButton = new Button(this.driver, by.EffectiveDateButton);
		
		transactionType = new TransactionType(this.driver);
		
		multiTransactionType = new TransactionSelector(this.driver, by.MultiTransactionType);
		DividendPeriod = new TextBox(this.driver, by.DividendPeriod);
		DividendPeriodButton = new Button(this.driver, by.DividendPeriodButton);
		YearEnd = new DropDown(this.driver, by.YearEnd);
		ActivityAsOfDate = new TextBox(this.driver, by.ActivityAsOfDate);
		ActivityAsOfDateButton = new Button(this.driver, by.ActivityAsOfDateButton);
		MRAEffectiveDate = new TextBox(this.driver, by.MRAEffectiveDate);
		MRAEffectiveDateButton = new Button(this.driver, by.MRAEffectiveDateButton);
		format = new Format(this.driver, by.Format);
		RenderReport = new Button(this.driver, by.RenderReport);
		Cancel = new Button(this.driver, by.Cancel);
		
		DateControl = new DateControl(this.driver);
		SelectAShareholder = new SelectAShareholder(this.driver);
		
		ErrorMessages = new ErrorMessages(this.driver, by.ErrorMessages);
	}
}
