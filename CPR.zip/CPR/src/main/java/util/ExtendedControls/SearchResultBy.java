package util.ExtendedControls;

import org.openqa.selenium.By;

public class SearchResultBy 
{
	public By Name = By.xpath(".//td[1]/a");
	public By CityState = By.xpath(".//td[2]");
	public By BPID = By.xpath(".//td[3]");
	public By Type = By.xpath(".//td[4]");
	public By TransacitonType = By.xpath(".//td[5]/select");
	public By EnterTransaction = By.xpath(".//td[5]/input[@value='Enter Transaction']");
}
