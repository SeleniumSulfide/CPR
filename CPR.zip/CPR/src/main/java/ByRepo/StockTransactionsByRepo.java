package ByRepo;

import org.openqa.selenium.By;

public class StockTransactionsByRepo 
{
	public By Purchase = By.xpath("//a[@href='#purchase']");
	public By Repurchase = By.xpath("//a[@href='#repurchase']");
	public By Redemption = By.xpath("//a[@href='#redemption']");
	public By Cancellation = By.xpath("//a[@href='#cancellation']");
	public By StockConversion = By.xpath("//a[@href='#conversion']");
	
	public class StockProfile
	{
		public By SelectShareholder = By.xpath("//*[@id='selectDifferetMember']");
		public By BPID = By.xpath("//*[@id='StockProfileViewModel_IfsId']");
		public By MemberName = By.xpath("//*[@id='StockProfileViewModel_MemberName']");
		public By CityState = By.xpath("//*[@id='StockProfileViewModel_CityState']");
		public By Status = By.xpath("//*[@id='StockProfileViewModel_MembershipStatus']");
		public By CMS = By.xpath("//*[@id='StockProfileViewModel_CMS']");
		public By TotalStockAmount = By.xpath("//*[@id='StockProfileViewModel_TotalStock']");
		public By AAmount = By.xpath("//*[@id='StockProfileViewModel_AStock']");
		public By B1Amount = By.xpath("//*[@id='StockProfileViewModel_B1Stock']");
		public By B2Amount = By.xpath("//*[@id='StockProfileViewModel_B2Stock']");
		public By StockRequirement = By.xpath("//*[@id='StockProfileViewModel_RequiredStock']");
		public By ExcessStock = By.xpath("//*[@id='StockProfileViewModel_ExcessStock']");
		public By StockAsOf = By.xpath("//*[@id='StockProfileViewModel_EffectiveAtBeginOfDate']");
		public By TotalAssets = By.xpath("//*[@id='StockProfileViewModel_TotalAssets']");
		public By MembershipRequirement = By.xpath("//*[@id='StockProfileViewModel_MembershipRequiredStock']");
		public By MembershipExcessStock = By.xpath("//*[@id='StockProfileViewModel_MembershipExcessStock']");
		public By ActivityRequirement = By.xpath("//*[@id='StockProfileViewModel_ActivityRequiredTotalStock']");
		public By RequiredA = By.xpath("//*[@id='StockProfileViewModel_ActivityRequiredAStock']");
		public By RequiredB = By.xpath("//*[@id='StockProfileViewModel_ActivityRequiredBStock']");
		public By ActivityExcessStock = By.xpath("//*[@id='StockProfileViewModel_ActivityExcessTotalStock']");
		public By ExcessA = By.xpath("//*[@id='StockProfileViewModel_ActivityExcessAStock']");
		public By ExcessB = By.xpath("//*[@id='StockProfileViewModel_ActivityExcessBStock']");
		public By TotalOutstandingRedemption = By.xpath("//*[@id='StockProfileViewModel_RedeemableStock']");
	}
	public StockProfile StockProfile = new StockProfile();
	
	public class StockCalculator
	{
		public By ViewShareholderStockCapacity = By.xpath("//*[@id='viewMemberStockCapacity']");
		public By StockAmount = By.xpath("//*[@id='StockCalculatorViewModel_StockAmount']");
		public By NumberOfShares = By.xpath("//*[@id='StockCalculatorViewModel_StockAmount']");
		public By ProjectedA = By.xpath("//*[@id='StockCalculatorViewModel_ProjectedA']");
		public By ProjectedB1 = By.xpath("//*[@id='StockCalculatorViewModel_ProjectedB1']");
		public By ProjectedB2 = By.xpath("//*[@id='StockCalculatorViewModel_ProjectedB2']");
	}
	public StockCalculator StockCalculator = new StockCalculator();
	
	public By ErrorMessagesXpath = By.xpath("//li[ancestor::div[@class='validation-summary-errors']]");
	public By ErrorMessages= By.cssSelector(".validation-summary-errors > ul:nth-child(1) > li");
	
	public class Terms
	{
		public By AmountTo = By.xpath("//input[@id[contains(.,'_Amount')]]");
		public By NoticeDate = By.xpath("//input[@id[contains(.,'_NoticeOn')]]");
		public By NoticeDateButton = By.xpath("//input[@id[contains(.,'_NoticeOn')]]/following-sibling::img");
		public By EffectiveDate = By.xpath("//input[@id[contains(.,'_EffectiveOn')]]");
		public By EffectiveDateButton = By.xpath("//input[@id[contains(.,'_EffectiveOn')]]/following-sibling::img");
		public By FundingDate = By.xpath("//input[@id[contains(.,'FundingOn')]]");
		public By FundingDateButton = By.xpath("//input[@id[contains(.,'_FundingOn')]]/following-sibling::img");
		public By Notes = By.xpath("//textarea[@id[contains(.,'_Notes')]]");
		public By Fee = By.xpath("//input[@id[contains(.,'_Fee')]]");
		public By LIFO = By.xpath("//input[@id[contains(.,'lifo')]]");
		public By Process = By.xpath("//input[@id[contains(.,'Process'");
		public By Cancel = By.xpath("//input[@id[contains(.,'Cancel'");
		public By TransactionType = By.xpath("//select[@id[contains(.,'Type') and not(contains(.,'_ClassType')) and not(contains(.,'_SelectedAccountType')) and not(contains(.,'_SelectedFeeType'))]]");
		public By StockClass = By.xpath("//select[@id[contains(.,'_ClassType')]]");
		public By RequestedBy = By.xpath("//*[@id=\"StockPurchaseViewModel_SelectedRequestBy\"]");
		public By Account = By.xpath("//select[@id[contains(.,'_SelectedAccountType')]]");
		public By FeeType = By.xpath("//select[@id[contains(.,'_SelectedFeeType')]]");
	}
	public Terms Terms = new Terms();
	
	public class StockTransactionTable
	{
		public By TableRows = By.xpath("//div[@class='sfhtData']/table[@id[contains(.,'stockTransactionTable')]]/tbody/tr");
		
		public class Transaction
		{
			public By AcquiredDate = By.xpath(".//td[1]");
			public By TransactionType = By.xpath(".//td[2]");
			public By StockClass = By.xpath(".//td[3]");
			public By OriginalStockAmount = By.xpath(".//td[4]");
			public By TransactionsFunded = By.xpath(".//td[5]");
			public By TransactionsPending = By.xpath(".//td[6]");
			public By AvailableAmount = By.xpath(".//td[7]");
			public By AmountOf = By.xpath(".//input[@id[contains(.,'Amount_')]]");
		}
		public Transaction Transaction = new Transaction();
	}
	public StockTransactionTable StockTransactionTable = new StockTransactionTable();
}
