package ByRepo;

import org.openqa.selenium.By;

public class HeaderByRepo
{
	public class SysInfo
	{
		public By SysDateXpath = By.xpath("//span[@class='systemDate']");
		public By EnvironmentXpath = By.xpath("//span[@class='environment']");
		public By CurrentUserXpath = By.xpath("//span[@class='username']");
		
		public By SysDate = By.cssSelector(".systemDate");
		public By Environment = By.cssSelector(".environment");
		public By CurrentUser = By.cssSelector(".username");		
	}
	public SysInfo sysInfo = new SysInfo();

	public class NavBar
	{
		public By HomeXpath = By.xpath("//a[text()='Home']");
		public By TransactionsXpath = By.xpath("//a[text()='Transactions']");
		public By ReportsXpath = By.xpath("//a[text()='Reports']");
		public By AdministrationXpath = By.xpath("//a[text()='Administration']");
		
		public By Home = By.cssSelector(".firstItem > a:nth-child(1)");
		public By Transactions = By.cssSelector(".topNavigation > li:nth-child(2) > a:nth-child(1)");
		public By Reports = By.cssSelector(".topNavigation > li:nth-child(3) > a:nth-child(1)");
		public By Administration = By.cssSelector(".lastItem > a:nth-child(1)");
		
		public class TransactionMenu
		{
			public By PurchaseXpath = By.xpath("//a[text()='Purchase' and @class[contains(.,'tabbedTransactions')]]");
			public By RepurchaseXpath = By.xpath("//a[text()='Repurchase' and @class[contains(.,'tabbedTransactions')]]");
			public By RedemptionXpath = By.xpath("//a[text()='Redemption' and @class[contains(.,'tabbedTransactions')]]");
			public By CancellationXpath = By.xpath("//a[text()='Cancellation' and @class[contains(.,'tabbedTransactions')]]");
			public By StockConversionXpath = By.xpath("//a[text()='Stock Conversion' and @class[contains(.,'tabbedTransactions')]]");
			public By DividendProjectionXpath = By.xpath("//a[text()='Dividend Projection']");
			public By TransferXpath = By.xpath("//a[text()='Transfer']");
			public By MergerXpath = By.xpath("//a[text()='Merger']");
			public By TransactionMaintenanceXpath = By.xpath("//a[text()='Transaction Maintenance']");
			public By TransactionBackdatingXpath = By.xpath("//a[text()='Transaction Backdating']");
			public By TransactionApprovalXpath = By.xpath("//a[text()='Transaction Approval']");
			public By MassRepurchaseXpath = By.xpath("//a[text()='Mass Repurchase']");
			
			public By Purchase = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(1) > a:nth-child(1)");
			public By Repurchase = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)");
			public By Redemption = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(3) > a:nth-child(1)");
			public By Cancellation = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(4) > a:nth-child(1)");
			public By StockConversion = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(5) > a:nth-child(1)");
			public By DividendProjection = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(6) > a:nth-child(1)");
			public By Transfer = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(7) > a:nth-child(1)");
			public By Merger = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(8) > a:nth-child(1)");
			public By TransactionMaintenance = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(9) > a:nth-child(1)");
			public By TransactionBackdating = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(10) > a:nth-child(1)");
			public By TransactionApproval = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(11) > a:nth-child(1)");
			public By MassRepurchase = By.cssSelector(".topNavigation > li:nth-child(2) > ul:nth-child(2) > li:nth-child(12) > a:nth-child(1)");
		}
		public TransactionMenu transactionMenu = new TransactionMenu();
		
		public class ReportsMenu
		{
			public By OutstandingRedemptionsReportXpath = By.xpath("//a[text()='Outstanding Redemptions Report']");
			public By CapitalStockNegativeExcessReportXpath = By.xpath("//a[text()='Capital Stock Negative Excess Report']");
			public By CapitalStockTransactionsReportXpath = By.xpath("//a[text()='Capital Stock Transactions Report']");
			public By CapitalStockTransactionsActivityReportXpath = By.xpath("//a[text()='Capital Stock Transactions Activity Report']");
			public By CapitalStockJournalEntriesReportXpath = By.xpath("//a[text()='Capital Stock Journal Entries Report']");
			public By CapitalStockTransactionsByMemberReportXpath = By.xpath("//a[text()='Capital Stock Transactions By Member Report']");
			public By CapitalStockBalanceReportXpath = By.xpath("//a[text()='Capital Stock Balance Report']");
			public By CapitalStockBalanceDetailsReportXpath = By.xpath("//a[text()='Capital Stock Balance Details Report']");
			public By CapitalStockDividendsReportXpath = By.xpath("//a[text()='Capital Stock Dividends Report']");
			public By CapitalStockTransactionHistoryXpath = By.xpath("//a[text()='Capital Stock Transaction History']");
			public By VotingSharesReportXpath = By.xpath("//a[text()='Voting Shares Report']");
			public By StockPercentageReportXpath = By.xpath("//a[text()='Stock Percentage Report']");
			public By CapitalStockProfileActivityReportXpath = By.xpath("//a[text()='Capital Stock Profile Activity Report']");
			public By CapitalStockTrialBalanceXpath = By.xpath("//a[text()='Capital Stock Trial Balance']");
			public By CapitalStockActivityRollforwardReportXpath = By.xpath("//a[text()='Capital Stock Activity Rollforward Report']");
			public By CapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemptionXpath = By.xpath("//a[text()='Capital Stock Trial Balance: Member Concentration and Excess Stock Subject to Redemption']");
			public By FAS150InterestExpenseReportXpath = By.xpath("//a[text()='FAS150 Interest Expense Report']");
			public By AMADetailsXpath = By.xpath("//a[text()='AMA Details']");
			public By AMATodayXpath = By.xpath("//a[text()='AMA Today']");
			public By MemberDividendHistoryReportXpath = By.xpath("//a[text()='Member Dividend History Report']");
			public By PendingTransactionsReportXpath = By.xpath("//a[text()='Pending Transactions Report']");
			public By CreditProductsDetailXpath = By.xpath("//a[text()='Credit Products Detail']");
			public By CapitalStockBackdatedTransactionReportXpath = By.xpath("//a[text()='Capital Stock Backdated Transaction Report']");
			public By CapitalStockAllShareholderSharesReportXpath = By.xpath("//a[text()='Capital Stock All Shareholder Shares Report']");
			
			public By OutstandingRedemptionsReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(1) > a:nth-child(1)");
			public By CapitalStockNegativeExcessReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(2) > a:nth-child(1)");
			public By CapitalStockTransactionsReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(3) > a:nth-child(1)");
			public By CapitalStockTransactionsActivityReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(4) > a:nth-child(1)");
			public By CapitalStockJournalEntriesReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(5) > a:nth-child(1)");
			public By CapitalStockTransactionsByMemberReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(6) > a:nth-child(1)");
			public By CapitalStockBalanceReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(7) > a:nth-child(1)");
			public By CapitalStockBalanceDetailsReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(8) > a:nth-child(1)");
			public By CapitalStockDividendsReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(9) > a:nth-child(1)");
			public By CapitalStockTransactionHistory = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(10) > a:nth-child(1)");
			public By VotingSharesReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(11) > a:nth-child(1)");
			public By StockPercentageReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(12) > a:nth-child(1)");
			public By CapitalStockProfileActivityReport = By.cssSelector("ul.newColumn:nth-child(1) > li:nth-child(13) > a:nth-child(1)");
			public By CapitalStockTrialBalance = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(1) > a:nth-child(1)");
			public By CapitalStockActivityRollforwardReport = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(2) > a:nth-child(1)");
			public By CapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(3) > a:nth-child(1)");
			public By FAS150InterestExpenseReport = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(4) > a:nth-child(1)");
			public By AMADetails = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(5) > a:nth-child(1)");
			public By AMAToday = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(6) > a:nth-child(1)");
			public By MemberDividendHistoryReport = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(7) > a:nth-child(1)");
			public By PendingTransactionsReport = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(8) > a:nth-child(1)");
			public By CreditProductsDetail = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(9) > a:nth-child(1)");
			public By CapitalStockBackdatedTransactionReport = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(10) > a:nth-child(1)");
			public By CapitalStockAllShareholderSharesReport = By.cssSelector("ul.newColumn:nth-child(2) > li:nth-child(11) > a:nth-child(1)");


		}
		public ReportsMenu reportsMenu = new ReportsMenu();
		
		public class AdministrationMenu
		{
			public By GlobalSettingsXpath = By.xpath("//a[text()='Global Settings']");
			public By StockTransactionBlackoutXpath = By.xpath("//a[text()='Stock Transaction Blackout']");
			public By StockRequirementSettingsXpath = By.xpath("//a[text()='Stock Requirement Settings']");
			public By TransactionDenialPeriodsXpath = By.xpath("//a[text()='Transaction Denial Periods']");
			public By AccountingAdministrationXpath = By.xpath("//a[text()='Accounting Administration']");
			public By ClassAStockSettingsXpath = By.xpath("//a[text()='Class A Stock Settings']");
			public By TotalAssetsLoadSetupXpath = By.xpath("//a[text()='Total Assets Load Setup']");
			
			public By GlobalSettings = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(1) > a:nth-child(1)");
			public By StockTransactionBlackout = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)");
			public By StockRequirementSettings = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(3) > a:nth-child(1)");
			public By TransactionDenialPeriods = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(4) > a:nth-child(1)");
			public By AccountingAdministration = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(5) > a:nth-child(1)");
			public By ClassAStockSettings = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(6) > a:nth-child(1)");
			public By TotalAssetsLoadSetup = By.cssSelector(".lastItem > ul:nth-child(2) > li:nth-child(7) > a:nth-child(1)");
		}
		public AdministrationMenu administrationMenu = new AdministrationMenu();
	}
	public NavBar navBar = new NavBar();
	
	public HeaderByRepo()
	{
		
	}
}
