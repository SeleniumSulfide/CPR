package ByRepo;

import org.openqa.selenium.By;

public class HomeByRepo 
{
	public By SearchCriteria = By.xpath("//input[@id='SearchTerm']");
	
	public By SearchXpath = By.xpath("//input[@value='Search']");
	public By Search = By.cssSelector(".width1_6 > input:nth-child(1)");
	
	public class ResultsGrid
	{
		public By NoResults = By.xpath("//div[@class='gridView memberSearchGrid']/tbody/tr/td[text()='No shareholders found for search term(s).']");
		public By TableRows = By.xpath("//div[@class='gridView memberSearchGrid']/table/tbody/tr");
		public By BPID;
		public By Name;
	}
	public ResultsGrid resultsGrid = new ResultsGrid();
}
