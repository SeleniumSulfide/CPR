package Administration.amaMemberOptIn;

import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.Label;
import util.BaseControls.TextBox;
import util.ExtendedControls.DateControl;

public class AddEditOptIn 
{
	WebDriver driver;
	public AddEditOptInBy by = new AddEditOptInBy();
	public DateControl DateControl;
	
	public Label MemberName;
	public TextBox EffectiveDate;
	public Button EffectiveDateButton;
	public Button OngoingFalse;
	public Button OngoingTrue;
	public TextBox EndDate;
	public Button EndDateButton;
	public Button Save;
	public Button Cancel;
	
	public AddEditOptIn(WebDriver driver)
	{
		this.driver = driver;
		DateControl = new DateControl(this.driver);
		MemberName = new Label(this.driver, by.MemberName);
		EffectiveDate = new TextBox(this.driver, by.EffectiveDate);
		EffectiveDateButton = new Button(this.driver, by.EffectiveDateButton);
		OngoingFalse = new Button(this.driver, by.OngoingFalse);
		OngoingTrue = new Button(this.driver, by.OngoingTrue);
		EndDate = new TextBox(this.driver, by.EndDate);
		EndDateButton = new Button(this.driver, by.EndDate);
		Save = new Button(this.driver, by.Save);
		Cancel = new Button(this.driver, by.Cancel);
	}
}
