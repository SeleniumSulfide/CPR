package Administration.amaMemberOptIn;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseControls.Button;
import util.ExtendedControls.SelectAShareholder;
import CapStock.Header;

public class amaMemberOptInControls 
{
	WebDriver driver;
	public Header Header;
	public amaMemberOptInBy by = new amaMemberOptInBy();
	
	public class ActiveRequirement
	{
		WebDriver driver;
		public Button AddMember;
		public AddEditOptIn AddEditOptIn;
		public SelectAShareholder SelectAShareholder;
		
		public List<RequirementActive> RequirementActive = new ArrayList<RequirementActive>();
		
		public void PopulateRequirementActive()
		{
			RequirementActive.clear();
			
			for (WebElement row : driver.findElements(by.RequirementActive.TableRows))
			{
				RequirementActive.add(new RequirementActive(row, this.driver));
			}
		}
		
		public ActiveRequirement(WebDriver driver)
		{
			this.driver = driver;
			AddMember = new Button(this.driver, by.RequirementActive.AddMember);
			AddEditOptIn = new AddEditOptIn(this.driver);
			SelectAShareholder = new SelectAShareholder(this.driver);
		}
	}
	public ActiveRequirement ActiveRequirement;
	
	public class HistoricalRequirement
	{
		WebDriver driver;
		public List<RequirementHistorical> RequirementHistorical = new ArrayList<RequirementHistorical>();
		
		public void PopulateRequirementHistorical()
		{
			RequirementHistorical.clear();
			
			for (WebElement row : driver.findElements(by.RequirementHistorical.TableRows))
			{
				RequirementHistorical.add(new RequirementHistorical(row, this.driver));
			}
		}
		public HistoricalRequirement(WebDriver driver)
		{
			this.driver = driver;
		}
	}
	public HistoricalRequirement HistoricalRequirement;
	
	public amaMemberOptInControls(WebDriver driver)
	{
		this.driver = driver;
		Header = new Header(this.driver);
		ActiveRequirement = new ActiveRequirement(this.driver);
		HistoricalRequirement = new HistoricalRequirement(this.driver);
	}
}
