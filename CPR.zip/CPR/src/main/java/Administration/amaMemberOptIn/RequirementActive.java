package Administration.amaMemberOptIn;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseControls.Button;
import util.BaseControls.Label;

public class RequirementActive 
{
	WebDriver driver;
	public RequirementActiveBy by = new RequirementActiveBy();
	public Label BPID;
	public Label MemberName;
	public Label StartDate;
	public Label EndDate;
	public Button Edit;
	
	public RequirementActive(WebElement row, WebDriver driver)
	{
		this.driver = driver;
		BPID = new Label(row, this.driver, by.BPID);
		MemberName = new Label(row, this.driver, by.MemberName);
		StartDate = new Label(row, this.driver, by.StartDate);
		EndDate = new Label(row, this.driver, by.EndDate);
		Edit = new Button(row, this.driver, by.Edit);
	}
}
