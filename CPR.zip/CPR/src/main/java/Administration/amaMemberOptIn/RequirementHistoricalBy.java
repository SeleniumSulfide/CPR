package Administration.amaMemberOptIn;

import org.openqa.selenium.By;

public class RequirementHistoricalBy 
{
	public By BPID = By.xpath("./td[1]");
	public By MemberName = By.xpath("./td[2]");
	public By StartDate = By.xpath("./td[3]");
	public By EndDate = By.xpath("./td[4]");
}
