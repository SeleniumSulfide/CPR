package Administration.amaMemberOptIn;

import org.openqa.selenium.By;

public class RequirementActiveBy 
{
	public By BPID = By.xpath("./td[2]");
	public By MemberName = By.xpath("./td[3]");
	public By StartDate = By.xpath("./td[4]");
	public By EndDate = By.xpath("./td[5]");
	public By Edit = By.xpath("./td[6]/button");
}
