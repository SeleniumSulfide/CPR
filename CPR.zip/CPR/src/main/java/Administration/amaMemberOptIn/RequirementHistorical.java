package Administration.amaMemberOptIn;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseControls.Label;

public class RequirementHistorical 
{
	WebDriver driver;
	public RequirementHistoricalBy by = new RequirementHistoricalBy();
	
	public Label BPID;
	public Label MemberName;
	public Label StartDate;
	public Label EndDate;
	
	public RequirementHistorical(WebElement row, WebDriver driver)
	{
		this.driver = driver;
		BPID = new Label(row, this.driver, by.BPID);
		MemberName = new Label(row, this.driver, by.MemberName);
		StartDate = new Label(row, this.driver, by.StartDate);
		EndDate = new Label(row, this.driver, by.EndDate);
	}
}
