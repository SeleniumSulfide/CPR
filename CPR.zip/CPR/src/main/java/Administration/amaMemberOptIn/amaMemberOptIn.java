package Administration.amaMemberOptIn;

import org.openqa.selenium.WebDriver;

public class amaMemberOptIn 
{
	WebDriver driver;
	public amaMemberOptInControls Controls;
	
	public amaMemberOptIn(WebDriver driver)
	{
		this.driver = driver;
		Controls = new amaMemberOptInControls(this.driver);
	}
}
