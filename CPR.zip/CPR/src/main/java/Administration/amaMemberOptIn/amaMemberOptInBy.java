package Administration.amaMemberOptIn;

import org.openqa.selenium.By;

public class amaMemberOptInBy 
{
	public class RequirementActive
	{
		public By TableRows = By.xpath("//h3[contains(text(),'Active AMA')]/following-sibling::section[1]/div/table/tbody/tr/td[not(text()='No rows Found.')]/parent::tr");
		public By AddMember = By.xpath("//input[@id='NewMemberAMAOptInRule']");
	}
	public RequirementActive RequirementActive = new RequirementActive();
	
	public class RequirementHistorical
	{
		public By TableRows = By.xpath("//h3[contains(text(),'Active AMA')]/following-sibling::section[2]/div/table/tbody/tr/td[not(text()='No rows Found.')]/parent::tr");
	}
	public RequirementHistorical RequirementHistorical = new RequirementHistorical();
}
