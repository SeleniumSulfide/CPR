package Administration.amaMemberOptIn;

import org.openqa.selenium.By;

public class AddEditOptInBy 
{
	public By Title = By.xpath("(//h3[contains(text(),'Add Active AMA')]|//h3[contains(text(),'Edit Active AMA')])");
	public By MemberName = By.xpath("//label[@for='Member_Name']/parent::td/following-sibling::td[@colspan=3]");
	
	public By EffectiveDate = By.xpath("//input[@id='EffectiveStartDate']");
	public By EffectiveDateButton = By.xpath("//input[@id='EffectiveStartDate']/following-sibling::img");
	
	public By OngoingTrue = By.xpath("//input[@id='IsOngoing_true']");
	public By OngoingFalse = By.xpath("//input[@id='IsOngoing_false']");
	
	public By EndDate = By.xpath("//input[@id='EffectiveEndDate']");
	public By EndDateButton = By.xpath("//input[@id='EffectiveEndDate']/following-sibling::img");
	
	public By Save = By.xpath("//button[span='Save']");
	public By Cancel = By.xpath("//button[span='Cancel']");
}
