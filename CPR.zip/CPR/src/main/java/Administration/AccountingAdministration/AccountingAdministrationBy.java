package Administration.AccountingAdministration;

import org.openqa.selenium.By;

public class AccountingAdministrationBy 
{
	public class AddRetractivePeriodAdjustment
	{
		public By FromDate = By.xpath("//input[@id='FromDate']"); 
		public By FromDateButton= By.xpath("//input[@id='FromDate']/following-sibling::img");
		
		public By ToDate = By.xpath("//input[@id='ToDate']"); 
		public By ToDateButton = By.xpath("//input[@id='ToDate']/following-sibling::img");
		
		public By PreviousRateB1 = By.xpath("//input[@id='PreviousRateClassB1']");
		public By PreviousRateB2 = By.xpath("//input[@id='PreviousRateClassB2']");
		public By PreviousRateA = By.xpath("//input[@id='PreviousRateClassA']");
		
		public By NewRateB1 = By.xpath("//input[@id='NewRateClassB1']");
		public By NewRateB2 = By.xpath("//input[@id='NewRateClassB2']");
		public By NewRateA = By.xpath("//input[@id='NewRateClassA']");
		
		public By AdjustmentRateB1 = By.xpath("//input[@id='AdjustmentRateClassB1']");
		public By AdjustmentRateB2 = By.xpath("//input[@id='AdjustmentRateClassB2']");
		public By AdjustmentRateA = By.xpath("//input[@id='AdjustmentRateClassA']");
		
		public By Final = By.xpath("//input[@id='finalizeAdjustmentButton']");
		public By Cancel = By.xpath("//input[@value='cancelAdjustmentButton']");
		
		public class ErrorMessages
		{
			public By ErrorSummary = By.xpath("//div[@class='validation-summary-errors']");
			public By Errors = By.xpath("//div[@class='validation-summary-errors']/child::ul/li");
		}
		public ErrorMessages ErrorMessages = new ErrorMessages();
	}
	public AddRetractivePeriodAdjustment AddRetractivePeriodAdjustment = new AddRetractivePeriodAdjustment();
	
	public class AccountingAdministration
	{
		public By AccrualRateB1 = By.xpath("//input[@id='DailyAccrualRateClassB1']");
		public By AccrualRateB2 = By.xpath("//input[@id='DailyAccrualRateClassB2']");
		public By AccrualRateA = By.xpath("//input[@id='DailyAccrualRateClassA']");
		public By GeneralLedgerClosingDays = By.xpath("//input[@id='GeneralLedgerClosingDays']");
		
		public By ChangeB1 = By.xpath("//input[@id='dailyAccrualRateB1Button']");
		public By ChangeB2 = By.xpath("//input[@id='dailyAccrualRateB2Button']");
		public By ChangeA = By.xpath("//input[@id='dailyAccrualRateAButton']");
		public By ChangeClosingDays = By.xpath("//input[@id='closingDaysButton']");
	}
	public AccountingAdministration AccrualRateAdministration = new AccountingAdministration();
	
	public class RetroactivePeriodHistory
	{
		public By TableRows = By.xpath("//h3[text()='Retroactive Period Adjustment History']/following-sibling::div[1]/table/tbody/tr/td[not(text()='No rows Found.')]/parent::tr");
		
	}
	public RetroactivePeriodHistory RetroactivePeriodHistory = new RetroactivePeriodHistory();
	
	public class AccountingAdministrationHistory
	{
		public By TableRows = By.xpath("//h3[text()='Accounting Administration History']/following-sibling::div[1]/table/tbody/tr/td[not(text()='No rows Found.')]/parent::tr");
		
	}
	public AccountingAdministrationHistory AccountingAdministrationHistory = new AccountingAdministrationHistory();
	
}
