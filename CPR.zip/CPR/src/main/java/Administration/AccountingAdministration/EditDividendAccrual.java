package Administration.AccountingAdministration;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseControls.Button;
import util.BaseControls.Label;
import util.BaseControls.TextBox;

public class EditDividendAccrual 
{
	WebDriver driver;
	public EditDividendAccrualBy by = new EditDividendAccrualBy();
	public Label Title;
	public Label RateLabel;
	public TextBox Rate;
	public Button Save;
	public Button Cancel;
	public List<String> ErrorMessages = new ArrayList<String>();
	
	public EditDividendAccrual(WebDriver driver)
	{
		this.driver = driver;
		Title = new Label(this.driver, by.Title);
		RateLabel = new Label(this.driver, by.RateLabel);
		Rate = new TextBox(this.driver, by.Rate);
		Save = new Button(this.driver, by.Save);
		Cancel = new Button(this.driver, by.Cancel);
	}
	
	public void populateErrorMessages()
	{
		ErrorMessages.clear();
		
		for (WebElement row : driver.findElements(by.Errors))
		{
			ErrorMessages.add(row.getText());
		}
	}
}
