package Administration.AccountingAdministration;

import org.openqa.selenium.By;

public class EditDividendAccrualBy 
{
	public By Title = By.xpath("//span[@id='ui-dialog-title-dialog']");
	public By RateLabel = By.xpath("//label[@for='Rate']");
	public By Rate = By.xpath("//input[@id='Rate']");
	public By Save = By.xpath("//button[@id='button-save']");
	public By Cancel = By.xpath("//button[@id='button-cancel']");
	public By Errors = By.xpath("//div[@id='dialog']/child::form/div[@class='validation-summary-errors']/child::ul/li");
}
