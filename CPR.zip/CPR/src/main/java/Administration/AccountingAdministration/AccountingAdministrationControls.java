package Administration.AccountingAdministration;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import CapStock.Header;
import Administration.AccountingAdministration.AccountingAdministrationBy;
import util.ExtendedControls.HistoryRow;
import util.BaseControls.Button;
import util.BaseControls.TextBox;
import util.ExtendedControls.DateControl;
import util.ExtendedControls.ConfirmationDialog;
import util.ExtendedControls.MessageDialog;

public class AccountingAdministrationControls 
{
	WebDriver driver;
	public AccountingAdministrationBy by = new AccountingAdministrationBy();
	public Header Header;
	public ConfirmationDialog ConfirmationDialog;
	public MessageDialog MessageDialog;
	public AddRetroactivePeriodAdjustment AddRetroactivePeriodAdjustment;
	public AccountingAdministration AccountingAdministration;
	
	public List<HistoryRow> RetroactiveHistory = new ArrayList<HistoryRow>();
	public List<HistoryRow> AccountingHistory = new ArrayList<HistoryRow>();
	
	public AccountingAdministrationControls(WebDriver driver)
	{
		this.driver = driver;
		Header = new CapStock.Header(this.driver);
		ConfirmationDialog = new ConfirmationDialog(this.driver);
		AddRetroactivePeriodAdjustment = new AddRetroactivePeriodAdjustment(this.driver);
		AccountingAdministration = new AccountingAdministration(this.driver);
	}
	
	public void populateRetroactiveHistory()
	{
		RetroactiveHistory.clear();
		
		for (WebElement row : driver.findElements(by.RetroactivePeriodHistory.TableRows))
		{
			RetroactiveHistory.add(new HistoryRow(row, this.driver));
		}
	}
	
	public void populateAccountingHistory()
	{
		AccountingHistory.clear();
		
		for (WebElement row : driver.findElements(by.AccountingAdministrationHistory.TableRows))
		{
			AccountingHistory.add(new HistoryRow(row, this.driver));
		}
	}
	
	public class AddRetroactivePeriodAdjustment
	{
		WebDriver driver;
		public DateControl DateControl;
		public List<String> ErrorMessages = new ArrayList<String>();
		
		public AddRetroactivePeriodAdjustment(WebDriver driver)
		{
			this.driver = driver;
			DateControl = new DateControl(this.driver);
			
			FromDate = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.FromDate);
			FromDateButton = new Button(this.driver, by.AddRetractivePeriodAdjustment.FromDateButton);
			
			ToDate = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.ToDate);
			ToDateButton = new Button(this.driver, by.AddRetractivePeriodAdjustment.ToDateButton);
			
			PreviousRateB1 = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.PreviousRateB1);
			PreviousRateB2 = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.PreviousRateB2);
			PreviousRateA = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.PreviousRateA);
			
			NewRateB1 = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.NewRateB1);
			NewRateB2 = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.NewRateB2);
			NewRateA = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.NewRateA);
			
			AdjustmentRateB1 = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.AdjustmentRateB1);
			AdjustmentRateB2 = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.AdjustmentRateB2);
			AdjustmentRateA = new TextBox(this.driver, by.AddRetractivePeriodAdjustment.AdjustmentRateA);
			
			Final = new Button(this.driver, by.AddRetractivePeriodAdjustment.Final);
			Cancel = new Button(this.driver, by.AddRetractivePeriodAdjustment.Cancel);
		}

		public void populateErrorMessages()
		{
			ErrorMessages.clear();
			
			for (WebElement row : driver.findElements(by.AddRetractivePeriodAdjustment.ErrorMessages.Errors))
			{
				ErrorMessages.add(row.getText());
			}
		}
		
		public TextBox FromDate;
		public Button FromDateButton;
		
		public TextBox ToDate;
		public Button ToDateButton;
		
		public TextBox PreviousRateB1;
		public TextBox PreviousRateB2;
		public TextBox PreviousRateA;
		
		public TextBox NewRateB1;
		public TextBox NewRateB2;
		public TextBox NewRateA;
		
		public TextBox AdjustmentRateB1;
		public TextBox AdjustmentRateB2;
		public TextBox AdjustmentRateA;
		
		public Button Final;
		public Button Cancel;
	}
	
	public class AccountingAdministration
	{
		WebDriver driver;
		
		public AccountingAdministration(WebDriver driver)
		{
			this.driver = driver;
			AccrualRateB1 = new TextBox(this.driver, by.AccrualRateAdministration.AccrualRateB1);
			AccrualRateB2 = new TextBox(this.driver, by.AccrualRateAdministration.AccrualRateB2);
			AccrualRateA = new TextBox(this.driver, by.AccrualRateAdministration.AccrualRateA);
			
			ChangeB1 = new Button(this.driver, by.AccrualRateAdministration.ChangeB1);
			ChangeB2 = new Button(this.driver, by.AccrualRateAdministration.ChangeB2);
			ChangeA = new Button(this.driver, by.AccrualRateAdministration.ChangeA);
			
			EditDividendAccrual = new EditDividendAccrual(this.driver);
		}
		
		public TextBox AccrualRateB1;
		public TextBox AccrualRateB2;
		public TextBox AccrualRateA;
		
		public Button ChangeB1;
		public Button ChangeB2;
		public Button ChangeA;
		
		public EditDividendAccrual EditDividendAccrual;
	}
}
