package Administration.StockRequirementSettings;

import org.openqa.selenium.By;

public class StockRequirementSettingsBy 
{
	public class TotalAssetSettings
	{
		public By Change = By.id("totalAssetsButton");
		public By RequirementSetting = By.id("TotalAssets_TotalAssetsPercentage");
		public By EffectiveDate = By.id("TotalAssets_TotalAssetsEffectiveDate");
		public By MinimumRequirement = By.id("TotalAssets_RequirementLimitsMinimum");
		public By CurrentMaximum = By.id("TotalAssets_RequirementLimitsMaximum");
	}
	public TotalAssetSettings TotalAssetSettings = new TotalAssetSettings();
	
	public class CapitalRatioRequirementSettings
	{
		public By Change = By.id("capitalRatioButton");
		public By CurrentCapitalRation = By.id("CapitalRatio_CurrentCapitalRatio");
		public By EffectiveDate = By.id("CapitalRatio_EffectiveDate");
		public By MinimumRationThreshold = By.id("CapitalRatio_Minimum");
		public By MaximumRationThreshold = By.id("CapitalRatio_Maximum");
	}
	public CapitalRatioRequirementSettings CapitalRatioRequirementSettiongs = new CapitalRatioRequirementSettings();
	
	public class LegacyTotalMortgageAssetsSettings
	{
		public By Change = By.id("mraButton");
		public By Percentage = By.id("Mra_Percentage");
		public By EffectiveDate = By.id("Mra_EffectiveDate");
		public By MinimumAmount = By.id("Mra_Minimum");
		public By MaximumAmount = By.id("Mra_Maximum");
	}
	public LegacyTotalMortgageAssetsSettings LegacyTotalMortgageAssetsSettings = new LegacyTotalMortgageAssetsSettings();
	
	public class ActivityBasedStockRequirementSettings
	{
		public class Advances
		{
			public class ClassA
			{
				public By Percentage = By.id("AdvancesClassA_Percentage");
				public By EffectiveDate = By.id("AdvancesClassA_EffectiveDate");
				public By Change = By.id("advancesClassAButton");
			}
			public ClassA ClassA = new ClassA();
			
			public class ClassB
			{
				public By Percentage = By.id("AdvancesClassB_Percentage");
				public By EffectiveDate = By.id("AdvancesClassB_EffectiveDate");
				public By Change = By.id("advancesClassBButton");
			}
			public ClassB ClassB = new ClassB();
		}
		public Advances Advances = new Advances();
		
		public class LinesOfCredit
		{
			public class ClassA
			{
				public By Percentage = By.id("LinesOfCreditClassA_Percentage");
				public By EffectiveDate = By.id("LinesOfCreditClassA_EffectiveDate");
				public By Change = By.id("linesOfCreditClassAButton");
			}
			public ClassA ClassA = new ClassA();
			
			public class ClassB
			{
				public By Percentage = By.id("LinesOfCreditClassB_Percentage");
				public By EffectiveDate = By.id("LinesOfCreditClassB_EffectiveDate");
				public By Change = By.id("linesOfCreditClassBButton");
			}
			public ClassB ClassB = new ClassB();
		}
		public LinesOfCredit LinesOfCredit = new LinesOfCredit();
		
		public class LettersOfCredit
		{
			public class ClassA
			{
				public By Percentage = By.id("LettersOfCreditClassA_Percentage");
				public By EffectiveDate = By.id("LettersOfCreditClassA_EffectiveDate");
				public By Change = By.id("lettersOfCreditClassAButton");
			}
			public ClassA ClassA = new ClassA();
			
			public class ClassB
			{
				public By Percentage = By.id("LettersOfCreditClassB_Percentage");
				public By EffectiveDate = By.id("LettersOfCreditClassB_EffectiveDate");
				public By Change = By.id("lettersOfCreditClassBButton");
			}
			public ClassB ClassB = new ClassB();
		}
		public LettersOfCredit LettersOfCredit = new LettersOfCredit();
		
		public class Derivatives
		{
			public class ClassA
			{
				public By Percentage = By.id("DerivativesClassA_Percentage");
				public By EffectiveDate = By.id("DerivativesClassA_EffectiveDate");
				public By Change = By.id("derivativesClassAButton");
			}
			public ClassA ClassA = new ClassA();
			
			public class ClassB
			{
				public By Percentage = By.id("DerivativesClassB_Percentage");
				public By EffectiveDate = By.id("DerivativesClassB_EffectiveDate");
				public By Change = By.id("derivativesClassBButton");
			}
			public ClassB ClassB = new ClassB();
		}
		public Derivatives Derivatives = new Derivatives();
		
		public class AMA
		{
			public class ClassA
			{
				public By Percentage = By.id("MppClassA_Percentage");
				public By EffectiveDate = By.id("MppClassA_EffectiveDate");
				public By Change = By.id("mppClassAButton");
			}
			public ClassA ClassA = new ClassA();
			
			public class ClassB
			{
				public By Percentage = By.id("MppClassB_Percentage");
				public By EffectiveDate = By.id("MppClassB_EffectiveDate");
				public By Change = By.id("mppClassBButton");
			}
			public ClassB ClassB = new ClassB();
		}
		public AMA AMA = new AMA();
		
		public class AMAOptIn
		{
			public class ClassA
			{
				public By Percentage = By.id("AMAOptInClassA_Percentage");
				public By EffectiveDate = By.id("AMAOptInClassA_EffectiveDate");
				public By Change = By.id("AMAOptInClassAButton");
			}
			public ClassA ClassA = new ClassA();
			
			public class ClassB
			{
				public By Percentage = By.id("AMAOptInClassB_Percentage");
				public By EffectiveDate = By.id("AMAOptInClassB_EffectiveDate");
				public By Change = By.id("AMAOptInClassBButton");
			}
			public ClassB ClassB = new ClassB();
		}
		public AMAOptIn AMAOptIn = new AMAOptIn();
	
		public class ChangeActivieSettings
		{
			public By DialogTitle = By.id("ui-dialog-title-dialog");
			public By Header = By.cssSelector("#dialog > form:nth-child(2) > section:nth-child(1) > h3:nth-child(5)");
			public By NewPercentage = By.id("Percentage");
			public By MinimumRangeText = By.id("MinimumPercentage");
			public By MinimumRangeEdit = By.id("minimumEditButton");
			public By MaximumRangeText = By.id("MaximumPercentage");
			public By MaximumRangeEdit = By.id("maximumEditButton");
			public By Prospective = By.id("IsProspective_true");
			public By Retrospective = By.id("IsProspective_false");
			public By ClassA = By.cssSelector("");
			public By ClassB = By.cssSelector("");
			public By EffectiveDate = By.id("EffectiveDate");
			public By EffecitveDateControl = By.id("ui-datepicker-trigger");
		}
		public ChangeActivieSettings ChangeActivieSettings = new ChangeActivieSettings();
	}
	public ActivityBasedStockRequirementSettings ActivityBasedStockRequirementSettings = new ActivityBasedStockRequirementSettings();
}
