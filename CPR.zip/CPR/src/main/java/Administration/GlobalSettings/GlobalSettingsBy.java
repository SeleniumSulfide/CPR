package Administration.GlobalSettings;

import org.openqa.selenium.By;

public class GlobalSettingsBy 
{
	private class EditSetting
	{
		public By DialogTitle = By.id("ui-dialog-title-dialog");
		public By Save = By.xpath("//button[span='Save']");
		public By Cancel = By.xpath("//button[span='Cancel']");
		public By ErrorMessages= By.cssSelector(".validation-summary-errors > ul:nth-child(1) > li");
	}
	
	public class RedemptionPeriod
	{
		public By ClassAPeriod = By.id("RedemptionPeriodClassA");
		public By ClassAUnit = By.id("RedemptionPeriodTimeUnitClassA");
		public By ClassBPeriod = By.id("RedemptionPeriodClassB");
		public By ClassBUnit = By.id("RedemptionPeriodTimeUnitClassB");
		public By Change = By.id("btnRedemptionPeriod");

		public class Edit extends EditSetting
		{
			public By ClassAPeriod = By.id("PeriodClassA");
			public By ClassAUnit = By.id("TimeUnitClassA");
			
			public By ClassBPeriod = By.id("PeriodClassB");
			public By ClassBUnit = By.id("TimeUnitClassB");
		}
		public Edit Edit = new Edit();
	}
	public RedemptionPeriod RedemptionPeriod = new RedemptionPeriod();
	
	public class RepurchaseTimeframe
	{
		public By ClassAPeriod = By.id("StockDividendRepurchasePeriodClassA");
		public By ClassBPeriod = By.id("StockDividendRepurchasePeriodClassB");
		public By Change = By.id("btnStockDivRepPeriod");
		
		public class Edit extends EditSetting
		{
			public By ClassAPeriod = By.cssSelector("div.inputValue:nth-child(3) > input:nth-child(1)");
			public By ClassBPeriod = By.cssSelector("div.inputValue:nth-child(2) > input:nth-child(1)");
		}
		public Edit Edit = new Edit();
	}
	public RepurchaseTimeframe RepurchaseTimeFrame = new RepurchaseTimeframe();
	
	public class BlackoutPeriod
	{
		public By ClassAPercent = By.id("BlackoutPeriodRequiredStockMaxPercentClassA");
		public By ClassBPercent = By.id("BlackoutPeriodRequiredStockMaxPercentClassB");
		public By Change = By.id("btnEditBlkPeriodReqStockMaxPct");
		
		public class Edit extends EditSetting
		{
			public By ClassAPercent = By.cssSelector("div.inputValue:nth-child(3) > input:nth-child(1)");
			public By ClassBPercent = By.cssSelector("div.inputValue:nth-child(2) > input:nth-child(1)");
		}
		public Edit Edit = new Edit();
	}
	public BlackoutPeriod BlackoutPeriod = new BlackoutPeriod();
	
	public class OwnershipTimeframe
	{
		public By ClassAPeriod = By.id("StockOwnershipForRepurchasePeriodClassA");
		public By ClassBPeriod = By.id("StockOwnershipForRepurchasePeriodClassB");
		public By Change = By.id("btnMinStockOwnPeriodForRep");
		
		public class Edit extends EditSetting
		{
			public By ClassAPeriod = By.cssSelector("div.inputValue:nth-child(3) > input:nth-child(1)");
			public By ClassBPeriod = By.cssSelector("div.inputValue:nth-child(2) > input:nth-child(1)");
		}
		public Edit Edit = new Edit();
	}
	public OwnershipTimeframe OwnershipTimeFrame = new OwnershipTimeframe();
}
