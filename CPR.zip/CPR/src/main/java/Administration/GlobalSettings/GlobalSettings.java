package Administration.GlobalSettings;

import org.openqa.selenium.WebDriver;

public class GlobalSettings 
{
	public WebDriver driver;
	public GlobalSettingsBy by = new GlobalSettingsBy();
	public GlobalSettingsControls Controls;
	
	public GlobalSettings(WebDriver driver)
	{
		this.driver = driver;
		Controls = new GlobalSettingsControls(this.driver);
	}
}
