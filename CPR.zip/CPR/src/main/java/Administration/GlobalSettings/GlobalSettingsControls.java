package Administration.GlobalSettings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.DropDown;
import util.BaseControls.ErrorMessages;
import util.BaseControls.Label;
import util.BaseControls.TextBox;

public class GlobalSettingsControls 
{
	WebDriver driver;
	
	public GlobalSettingsBy by = new GlobalSettingsBy();
	public CapStock.Header Header;
	
	public class RedemptionPeriod
	{
		WebDriver driver;
		public TextBox ClassAPeriod;
		public Label ClassAUnit;
		public TextBox ClassBPeriod;
		public Label ClassBUnit;
		public Button Change;
		public class EditSettings
		{
			public class TimeUnit extends DropDown
			{
				public TimeUnit(WebDriver driver, By by) { super(driver, by); }
				public void SetYears() { SetByVisibleText("Years"); }
				public void SetMonts() { SetByVisibleText("Months"); }
				public void SetDays() { SetByVisibleText("Days"); }
			}
			
			WebDriver driver;
			
			public TextBox ClassAPeriod;
			public TimeUnit ClassAUnit;
			
			public TextBox ClassBPeriod;
			public TimeUnit ClassBUnit;
			
			public Button Save;
			public Button Cancel;
			
			public ErrorMessages errorMessaging;
			
			public EditSettings(WebDriver driver)
			{
				this.driver = driver;
				ClassAPeriod = new TextBox(this.driver, by.RedemptionPeriod.Edit.ClassAPeriod);
				ClassAUnit = new TimeUnit(this.driver, by.RedemptionPeriod.Edit.ClassAUnit);
				ClassBPeriod = new TextBox(this.driver, by.RedemptionPeriod.Edit.ClassBPeriod);
				ClassBUnit = new TimeUnit(this.driver, by.RedemptionPeriod.Edit.ClassBUnit);
				Save = new Button(this.driver, by.RedemptionPeriod.Edit.Save);
				Cancel = new Button(this.driver, by.RedemptionPeriod.Edit.Cancel);
				errorMessaging = new ErrorMessages(this.driver, by.RedemptionPeriod.Edit.ErrorMessages);
			}
		}
		public EditSettings editSettings;
		
		public RedemptionPeriod(WebDriver driver)
		{
			this.driver = driver;
			ClassAPeriod = new TextBox(this.driver, by.RedemptionPeriod.ClassAPeriod);
			ClassAUnit = new Label(this.driver, by.RedemptionPeriod.ClassAUnit);
			ClassBPeriod = new TextBox(this.driver, by.RedemptionPeriod.ClassBPeriod);
			ClassBUnit = new Label(this.driver, by.RedemptionPeriod.ClassBUnit);
			Change = new Button(this.driver, by.RedemptionPeriod.Change);
			editSettings = new EditSettings(this.driver);
		}
	}
	public RedemptionPeriod RedemptionPeriod;
	
	public class RepurchaseTimeframe
	{
		WebDriver driver;
		public TextBox ClassAPeriod;
		public TextBox ClassBPeriod;
		public Button Change;
		
		public class EditSettings
		{
			WebDriver driver;
			public TextBox ClassAPeriod;
			public TextBox ClassBPeriod;
			public Button Save;
			public Button Cancel;
			public ErrorMessages errorMessaging;
			
			public EditSettings(WebDriver driver)
			{
				this.driver = driver;
				ClassAPeriod = new TextBox(this.driver, by.RepurchaseTimeFrame.Edit.ClassAPeriod);
				ClassBPeriod = new TextBox(this.driver, by.RepurchaseTimeFrame.Edit.ClassBPeriod);
				Save = new Button(this.driver, by.RepurchaseTimeFrame.Edit.Save);
				Cancel = new Button(this.driver, by.RepurchaseTimeFrame.Edit.Cancel);
				errorMessaging = new ErrorMessages(this.driver, by.RepurchaseTimeFrame.Edit.ErrorMessages);
			}
		}
		public EditSettings editSettings;
		
		public RepurchaseTimeframe(WebDriver driver)
		{
			this.driver = driver;
			ClassAPeriod = new TextBox(this.driver, by.RepurchaseTimeFrame.ClassAPeriod);
			ClassBPeriod = new TextBox(this.driver, by.RepurchaseTimeFrame.ClassBPeriod);
			Change = new Button(this.driver, by.RepurchaseTimeFrame.Change);
			editSettings = new EditSettings(this.driver);
		}
	}
	public RepurchaseTimeframe RepurchaseTimeframe;
	
	public class BlackoutPeriod
	{
		WebDriver driver;
		public TextBox ClassAPercent;
		public TextBox ClassBPercent;
		public Button Change;
		
		public class EditSettings
		{
			WebDriver driver;
			public TextBox ClassAPercent;
			public TextBox ClassBPercent;
			public Button Save;
			public Button Cancel;
			public ErrorMessages errorMessaging;
			
			public EditSettings(WebDriver driver)
			{
				this.driver = driver;
				ClassAPercent = new TextBox(this.driver, by.BlackoutPeriod.Edit.ClassAPercent);
				ClassBPercent = new TextBox(this.driver, by.BlackoutPeriod.Edit.ClassBPercent);
				Save = new Button(this.driver, by.BlackoutPeriod.Edit.Save);
				Cancel = new Button(this.driver, by.BlackoutPeriod.Edit.Cancel);
				errorMessaging = new ErrorMessages(this.driver, by.BlackoutPeriod.Edit.ErrorMessages);
			}
		}
		public EditSettings editSettings;
		
		public BlackoutPeriod(WebDriver driver)
		{
			this.driver = driver;
			ClassAPercent = new TextBox(this.driver, by.BlackoutPeriod.ClassAPercent);
			ClassBPercent = new TextBox(this.driver, by.BlackoutPeriod.ClassBPercent);
			Change = new Button(this.driver, by.BlackoutPeriod.Change);
			editSettings = new EditSettings(this.driver);
		}
	}
	public BlackoutPeriod BlackoutPeriod;
	
	public class OwnershipTimeframe
	{
		WebDriver driver;
		public TextBox ClassAPeriod;
		public TextBox ClassBPeriod;
		public Button Change;
		
		public class EditSettings
		{
			WebDriver driver;
			public TextBox ClassAPeriod;
			public TextBox ClassBPeriod;
			public Button Save;
			public Button Cancel;
			public ErrorMessages errorMessaging;
			
			public EditSettings(WebDriver driver)
			{
				this.driver = driver;
				ClassAPeriod = new TextBox(this.driver, by.OwnershipTimeFrame.Edit.ClassAPeriod);
				ClassBPeriod = new TextBox(this.driver, by.OwnershipTimeFrame.Edit.ClassBPeriod);
				Save = new Button(this.driver, by.OwnershipTimeFrame.Edit.Save);
				Cancel = new Button(this.driver, by.OwnershipTimeFrame.Edit.Cancel);
				errorMessaging = new ErrorMessages(this.driver, by.OwnershipTimeFrame.Edit.ErrorMessages);
			}
		}
		public EditSettings editSettings;
		
		public OwnershipTimeframe(WebDriver driver)
		{
			this.driver = driver;
			ClassAPeriod = new TextBox(this.driver, by.OwnershipTimeFrame.ClassAPeriod);
			ClassBPeriod = new TextBox(this.driver, by.OwnershipTimeFrame.ClassBPeriod);
			Change = new Button(this.driver, by.OwnershipTimeFrame.Change);
		}
	}
	public OwnershipTimeframe OwnershipTimeframe;
	
	public GlobalSettingsControls(WebDriver driver)
	{
		this.driver = driver;
		Header = new CapStock.Header(this.driver);
		RedemptionPeriod = new RedemptionPeriod(this.driver);
		RepurchaseTimeframe = new RepurchaseTimeframe(this.driver);
		BlackoutPeriod = new BlackoutPeriod(this.driver);
		OwnershipTimeframe = new OwnershipTimeframe(this.driver);
	}
}
