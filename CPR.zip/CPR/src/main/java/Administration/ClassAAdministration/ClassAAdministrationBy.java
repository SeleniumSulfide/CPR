package Administration.ClassAAdministration;

import org.openqa.selenium.By;

public class ClassAAdministrationBy 
{
	
	public class ClassAStockDashboard
	{
		public By TotalShares = By.id("TotalShares");
		public By AvailableSharesZero = By.id("AvailableSharesZero");
		public By AvailableShares = By.id("AvailableShares");
		public By Available = By.xpath("//input[@id='ClassAPurchaseYesNo']/parent::td");
		public By Edit = By.id("ClassAPurchaseYesNo");
	}
	public ClassAStockDashboard ClassAStockDashboard = new ClassAStockDashboard();
	
	
	public class ActiveClassAStockSettings
	{
		public By StartDate = By.id("StartDate");
		public By EndDate = By.id("EndDate");
		public By GlobalShareUnlimited = By.id("UnlimitedShares");
		public By GlobalShareLimit = By.id("ShareLimit");
		public By GlobalShareLimitType = By.id("GlobalShareTypeText");
		public By MemberUpToGlobalLimit = By.id("UptoGlobalLimitShares");
		public By MemberShareLimit = By.id("MemberLimit");
		public By MemberShareLimitType = By.id("MemberShareTypeText");
		public By EditStockSettings = By.id("ClassAActiveSettings");
	}
	public ActiveClassAStockSettings ActiveClassAStockSettings = new ActiveClassAStockSettings();
	
	
	public class MemberSpecificLimit
	{
		public By TableRows = By.xpath("//h3[text()='Specific Member Outstanding Share Limit for Class A:']/following-sibling::section[1]/descendant::table/tbody/tr/td[not(text()='No rows Found.')]/parent::tr");
		public By Add = By.xpath("//input[@id='ClassASettingsShareholder']");
	}
	public MemberSpecificLimit MemberSpecificLimit = new MemberSpecificLimit();
	
	
	public class History
	{
		public By TableRows = By.xpath("//h3[text()='History']/following-sibling::section/descendant::table/tbody/tr/td[not(text()='No rows Found.')]/parent::tr");
	}
	public History History = new History();
}
