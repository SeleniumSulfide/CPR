package Administration.ClassAAdministration;

import java.util.Date;

import org.openqa.selenium.WebDriver;

import Administration.ClassAAdministration.ClassAAdministrationControls;
import CapStock.App;
import util.BaseControls.Button;

public class ClassAAdministration 
{
	public WebDriver driver;
	public App app;
	public ClassAAdministrationControls Controls;
	
	public ClassAAdministration(WebDriver driver)
	{
		this.driver = driver;
		Controls = new ClassAAdministrationControls(this.driver);
		app = new App(this.driver);
	}
	
	
	public class ClassAStockDashboard
	{
		public Integer TotalShares()
		{
			return Integer.parseInt(Controls.ClassAStockDashboard.TotalShares.GetText().replace("$", ""));
		}
		
		public Integer TotalAvailable()
		{
			if (Controls.ClassAStockDashboard.AvailableShares.isDisplayed())
			{
				return Integer.parseInt(Controls.ClassAStockDashboard.AvailableShares.GetText().replace("$", ""));
			}
			else if (Controls.ClassAStockDashboard.AvailableSharesZero.isDisplayed())
			{
				return Integer.parseInt(Controls.ClassAStockDashboard.AvailableSharesZero.GetText().replace("$", ""));
			}
			else
			{
				return null;
			}
		}
		
		public Boolean Available()
		{
			switch (Controls.ClassAStockDashboard.Available.GetText())
			{
				case "Yes": return true; 
				case "No": return false;
				default: return null;
			}
		}
		
		public String SetAvaialbleNo()
		{
			return SetAvailable(Controls.ClassAStockDashboard.EditClassAAvailable.No);			
		}
		
		public String SetAvaialbleYes()
		{
			return SetAvailable(Controls.ClassAStockDashboard.EditClassAAvailable.Yes);
		}
		
		private String SetAvailable(Button Button)
		{
			Controls.ClassAStockDashboard.Edit.Click();
			app.fluentWaitForElement(Controls.ClassAStockDashboard.EditClassAAvailable.Title.GetElement());
			Button.Click();
			Controls.ClassAStockDashboard.EditClassAAvailable.Save.Click();
			String Message = Controls.MessageDialog.Message.GetText();
			Controls.MessageDialog.OK.Click();
			app.fluentWaitForElement(Controls.ClassAStockDashboard.Edit.GetElement());
			return Message;
		}
	}
	public ClassAStockDashboard ClassAStockDashboard = new ClassAStockDashboard();
	
	
	public class ActiveStockSettings
	{
		public Date StartDate()
		{
			return app.parseDate(Controls.ActiveStockSettings.StartDate.GetText());
		}
		
		public Date EndDate()
		{
			return app.parseDate(Controls.ActiveStockSettings.EndDate.GetText());
		}
		
		public Integer GlobalShareLimit()
		{
			if (Controls.ActiveStockSettings.GlobalShareUnlimited.isDisplayed())
			{
				return null;
			}
			else
			{
				return Integer.parseInt(Controls.ActiveStockSettings.GlobalShareLimit.GetText().replace("$", ""));
			}
		}
		
		public String GlobalLimitType()
		{
			return Controls.ActiveStockSettings.GlobalShareLimitType.GetText();
		}
		
		public Integer MemberShareLimit()
		{
			if (Controls.ActiveStockSettings.MemberUpToGlobalLimit.isDisplayed())
			{
				return null;
			}
			else
			{
				return Integer.parseInt(Controls.ActiveStockSettings.MemberShareLimit.GetText().replace("$", ""));
			}
		}
		
		public String MemberLimitType()
		{
			return Controls.ActiveStockSettings.MemberShareLimitType.GetText();
		}
		
		
	}
	public ActiveStockSettings ActiveStockSettings = new ActiveStockSettings();
	
	
	public class SpecificLimit
	{
		
	}
	public SpecificLimit SpecificLimit = new SpecificLimit();
	
	
	public class History
	{
		
	}
	public History History = new History();
	
}
