package Administration.ClassAAdministration;

import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.Label;

public class EditClassAAvailable
{
	EditClassAAvailableBy by = new EditClassAAvailableBy();
	WebDriver driver;
	public Label Title;
	public Button Yes;
	public Button No;
	public Button Save;
	public Button Cancel;
	
	public EditClassAAvailable(WebDriver driver)
	{
		this.driver = driver;
		
		Title = new Label(this.driver, by.Title);
		Yes = new Button(this.driver, by.AvailableYes);
		No = new Button(this.driver, by.AvailableNo);
		Save = new Button(this.driver, by.Save);
		Cancel = new Button(this.driver, by.Cancel);
	}
}
