package Administration.ClassAAdministration;

import org.openqa.selenium.By;

public class EditClassAAvailableBy
{
	public By Title = By.id("ui-dialog-title-dialog");
	public By AvaialbeLabel = By.xpath("//*[@id='ui-dialog-title-dialog']/following::label[@for='CanWePurchase']");
	public By AvailableYes = By.xpath("//input[@id='CanWePurchase' and @value='True']");
	public By AvailableNo = By.xpath("//input[@id='CanWePurchase' and @value='False']");
	public By Save = By.xpath("//button[span='Save']");
	public By Cancel = By.xpath("//button[span='Cancel']");
}
