package Administration.ClassAAdministration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import util.BaseControls.Button;
import util.BaseControls.DropDown;
import util.BaseControls.TextBox;
import util.ExtendedControls.DateControl;

public class EditActiveStockSetting 
{
	WebDriver driver;
	public EditActiveStockSettingBy by = new EditActiveStockSettingBy();
	
	public DateControl DateControl;
	public TextBox StartDate;
	public Button StartDateButton;
	public Button OngoingFalse;
	public Button OngoingTrue;
	public TextBox EndDate;
	public Button EndDateButton;
	public Button GlobalShareLimited;
	public Button GlobalShareUnlimited;
	public LimitType GlobalShareLimitType;
	public Button MemberShareLimited;
	public Button MemberShareUnlimited;
	public LimitType MemberShareLimitType;
	
	public class LimitType extends DropDown
	{
		public LimitType(WebDriver driver, By by) { super(driver, by); }
		
		public void SetOverallLimit() { SetByVisibleText("Overall Limit"); }
		
		public void SetOfferLimit() { SetByVisibleText("Offer Limit"); }
	}
	
	public EditActiveStockSetting(WebDriver driver)
	{
		this.driver = driver;
		DateControl = new DateControl(this.driver);
		StartDate = new TextBox(this.driver, by.StartDate);
		StartDateButton = new Button(this.driver, by.StartDateButton);
		OngoingFalse = new Button(this.driver, by.OngoingFalse);
		OngoingTrue = new Button(this.driver, by.OngoingTrue);
		EndDate = new TextBox(this.driver, by.EndDate);
		EndDateButton = new Button(this.driver, by.EndDateButton);
		GlobalShareLimited = new Button(this.driver, by.GlobalShareLimited);
		GlobalShareUnlimited = new Button(this.driver, by.GlobalShareUnlimited);
		GlobalShareLimitType = new LimitType(this.driver, by.GlobalShareLimitType);
		MemberShareLimited = new Button(this.driver, by.MemberShareLimited);
		MemberShareUnlimited = new Button(this.driver, by.MemberShareUnlimited);
		MemberShareLimitType = new LimitType(this.driver, by.MemberShareLimitType);
	}
}
