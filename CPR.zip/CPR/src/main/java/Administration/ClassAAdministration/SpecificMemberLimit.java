package Administration.ClassAAdministration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import util.BaseControls.Button;

public class SpecificMemberLimit 
{
	WebDriver driver;
	
	private SpecificMemberLimitBy by = new SpecificMemberLimitBy();
	
	public Integer BPID;
	public String MemberName;
	public Integer LimitAmount;
	public Boolean AllowedToPurchase;
	public Button Delete;
	public Button Edit;
	
	public SpecificMemberLimit(WebElement row, WebDriver driver)
	{
		this.driver = driver;
		
		BPID = Integer.parseInt(row.findElement(by.BPID).getText());
		MemberName = row.findElement(by.BPID).getText();
		LimitAmount = Integer.parseInt(row.findElement(by.BPID).getText().replace("$", "").replace(",", ""));
		Delete = new Button(row, this.driver, by.Delete);
		Edit = new Button(row, this.driver, by.Edit);
		
		
	}
}
