package Administration.ClassAAdministration;

import org.openqa.selenium.By;

public class SpecificMemberLimitBy 
{
	public By BPID = By.xpath(".//td[1]");
	public By MemberName = By.xpath(".//td[2]");
	public By LimitAmount = By.xpath(".//td[3]");
	public By AllowedToPurchase = By.xpath(".//td[4]");
	public By Delete = By.xpath(".//td[5]/button[text()='Delete']");
	public By Edit = By.xpath(".//td[5]/button[text()='Edit']");
}
