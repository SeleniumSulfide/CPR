package Administration.ClassAAdministration;

import org.openqa.selenium.By;

public class EditActiveStockSettingBy 
{
	public By StartDate = By.id("StartDateInput");
	public By StartDateButton = By.xpath("//input[@id='StartDateInput']/following-sibling::img");
	public By OngoingFalse = By.id("IsOngoing_false");
	public By OngoingTrue = By.id("IsOngoing_true");
	public By EndDate = By.id("EndDateInput");
	public By EndDateButton = By.xpath("//input[@id='EndDateInput']/following-sibling::img");
	public By GlobalShareLimited = By.id("//input[@id='GlobalShareUnlimitd' and @value='False']");
	public By GlobalShareUnlimited = By.id("//input[@id='GlobalShareUnlimitd' and @value='True']");
	public By GlobalShareLimitType = By.id("GlobalShareType");
	public By MemberShareLimited = By.id("//input[@id='MemberShareToGlobal' and @value='False']");
	public By MemberShareUnlimited = By.id("//input[@id='MemberShareToGlobal' and @value='True']");
	public By MemberLimit = By.id("MemberLimitEdit");
	public By MemberShareLimitType = By.id("MemberShareType");
	public By Save = By.xpath("//button[span='Save']");
	public By Cancel = By.xpath("//button[span='Cancel']");
}
