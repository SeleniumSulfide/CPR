package Administration.ClassAAdministration;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import CapStock.Header;
import util.BaseControls.Button;
import util.BaseControls.Label;
import util.BaseControls.TextBox;
import util.ExtendedControls.HistoryRow;
import util.ExtendedControls.MessageDialog;

public class ClassAAdministrationControls 
{
	WebDriver driver;
	public ClassAAdministrationBy by = new ClassAAdministrationBy();
	public Header Header;
	public MessageDialog MessageDialog;
	public List<HistoryRow> History = new ArrayList<HistoryRow>();
	public List<SpecificMemberLimit> SpecificMemberLimit = new ArrayList<SpecificMemberLimit>();
	
	public ClassAAdministrationControls(WebDriver driver)
	{
		this.driver = driver;
		Header = new Header(this.driver);
		MessageDialog = new MessageDialog(this.driver);
		ClassAStockDashboard = new ClassAStockDashboard(this.driver);
		ActiveStockSettings = new ActiveStockSettings(this.driver);
	}
	
	public void populateHistoryTable()
	{
		History.clear();
		
		for (WebElement row : driver.findElements(by.History.TableRows))
		{
			History.add(new HistoryRow(row, this.driver));
		}
	}
	
	public void populateSpecificMemberLimit()
	{
		SpecificMemberLimit.clear();
		
		for (WebElement row : driver.findElements(by.MemberSpecificLimit.TableRows))
		{
			SpecificMemberLimit.add(new SpecificMemberLimit(row, this.driver));
		}
	}
	
	public class ClassAStockDashboard
	{
		WebDriver driver;
		public TextBox TotalShares;
		public TextBox AvailableSharesZero;
		public TextBox AvailableShares;
		public Label Available;
		public Button Edit;
		public EditClassAAvailable EditClassAAvailable;
		
		public ClassAStockDashboard(WebDriver driver)
		{
			this.driver = driver;
			
			EditClassAAvailable = new EditClassAAvailable(this.driver);
			TotalShares = new TextBox(this.driver, by.ClassAStockDashboard.TotalShares);
			AvailableSharesZero = new TextBox(this.driver, by.ClassAStockDashboard.AvailableSharesZero);
			AvailableShares = new TextBox(this.driver, by.ClassAStockDashboard.AvailableShares);
			Available = new Label(this.driver, by.ClassAStockDashboard.Available);
			Edit = new Button(this.driver, by.ClassAStockDashboard.Edit);
		}
	}
	public ClassAStockDashboard ClassAStockDashboard;
	
	
	public class ActiveStockSettings
	{ 
		WebDriver driver;
		public TextBox StartDate;
		public TextBox EndDate;
		public TextBox GlobalShareUnlimited;
		public TextBox GlobalShareLimit;
		public TextBox GlobalShareLimitType;
		public TextBox MemberUpToGlobalLimit;
		public TextBox MemberShareLimit;
		public TextBox MemberShareLimitType;
		public Button EditStockSettings;
		public EditActiveStockSetting EditActiveStockSetting;
		
		public ActiveStockSettings(WebDriver driver)
		{
			this.driver = driver;
			StartDate = new TextBox(this.driver, by.ActiveClassAStockSettings.StartDate);
			EndDate = new TextBox(this.driver, by.ActiveClassAStockSettings.StartDate);
			GlobalShareUnlimited = new TextBox(this.driver, by.ActiveClassAStockSettings.GlobalShareUnlimited);
			GlobalShareLimit = new TextBox(this.driver, by.ActiveClassAStockSettings.GlobalShareLimit);
			GlobalShareLimitType = new TextBox(this.driver, by.ActiveClassAStockSettings.GlobalShareLimitType);
			MemberUpToGlobalLimit = new TextBox(this.driver, by.ActiveClassAStockSettings.MemberUpToGlobalLimit);
			MemberShareLimit = new TextBox(this.driver, by.ActiveClassAStockSettings.MemberShareLimit);
			MemberShareLimitType = new TextBox(this.driver, by.ActiveClassAStockSettings.MemberShareLimitType);
			EditStockSettings = new Button(this.driver, by.ActiveClassAStockSettings.EditStockSettings);
			EditActiveStockSetting = new EditActiveStockSetting(this.driver);
		}
	}
	public ActiveStockSettings ActiveStockSettings;
}
