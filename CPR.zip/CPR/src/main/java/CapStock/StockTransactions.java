package CapStock;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import ByRepo.StockTransactionsByRepo;
import util.BaseControls.Button;
import util.BaseControls.DropDown;
import util.BaseControls.ErrorMessages;
import util.BaseControls.TextBox;
import util.Data.MSSQL;
import util.ExtendedControls.ConfirmationDialog;
import util.ExtendedControls.DateControl;
import util.ExtendedControls.MessageDialog;
import util.ExtendedControls.SelectAShareholder;

public class StockTransactions 
{
	WebDriver driver;
	MSSQL sql;
	App app;
	
	public StockTransactionsByRepo by = new StockTransactionsByRepo();
	
	public StockProfile StockProfile;
	public StockCalculator StockCalculator;
	public ErrorMessages ErrorMessages;
	public Terms Terms;
	public StockTransactionTable StockTransactionTable;
	
	
	public Button Purchase;
	public Button Repurchase;
	public Button Redemption;
	public Button Cancellation;
	public Button StockConversion;
	
	public SelectAShareholder SelectAShareholder;
	
	public MessageDialog MessageDialog;
	public ConfirmationDialog ConfirmationDialog;
	
	public StockTransactions(WebDriver driver, MSSQL sql) 
	{ 
		this.driver = driver;
		this.sql = sql;
		app = new App(this.driver);
		Purchase = new Button(this.driver, by.Purchase);
		Repurchase = new Button(this.driver, by.Repurchase);
		Redemption = new Button(this.driver, by.Redemption);
		Cancellation = new Button(this.driver, by.Cancellation);
		StockConversion = new Button(this.driver, by.StockConversion);
		StockProfile = new StockProfile(this.driver, this.sql);
		StockCalculator = new StockCalculator(this.driver);
		ErrorMessages = new ErrorMessages(this.driver, by.ErrorMessages);
		Terms = new Terms(this.driver);
		StockTransactionTable = new StockTransactionTable(this.driver);
		SelectAShareholder = new SelectAShareholder(this.driver);
		MessageDialog = new MessageDialog(this.driver);
		ConfirmationDialog = new ConfirmationDialog(this.driver);
	} 
	
	public class StockProfile
	{		
		WebDriver driver;
		MSSQL sql;
		
		public Button SelectShareholder;
		public TextBox BPID;
		public TextBox MemberName;
		public TextBox CityState;
		public TextBox Status;
		public TextBox CMS;
		public TextBox TotalStockAmount;
		public TextBox TotalStockAmountA;
		public TextBox TotalStockAmountB1;
		public TextBox TotalStockAmountB2;
		public TextBox StockRequirementAmount;
		public TextBox StockRequirementExcess;
		public TextBox StockAsOf;
		public TextBox TotalAssets;
		public TextBox MembershipRequirement;
		public TextBox MembershipExcessStock;
		public TextBox ActivityRequirement;
		public TextBox ActivityRequirementA;
		public TextBox ActivityRequirementB;
		public TextBox ActivityExcessStock;
		public TextBox ActivityExcessStockA;
		public TextBox ActivityExcessStockB;
		public TextBox TotalOutstandingRedemption;
		public Profile WebProfile;
		
		public StockProfile(WebDriver driver, MSSQL sql)
		{
			this.driver = driver;
			this.sql = sql;
			InitObjects();
			
		}
		
		private void InitObjects()
		{
			SelectShareholder = new Button(this.driver, by.StockProfile.SelectShareholder);
			BPID = new TextBox(this.driver, by.StockProfile.BPID);
			MemberName = new TextBox(this.driver, by.StockProfile.MemberName);
			CityState = new TextBox(this.driver, by.StockProfile.CityState);
			Status = new TextBox(this.driver, by.StockProfile.Status);
			CMS = new TextBox(this.driver, by.StockProfile.CMS);
			TotalStockAmount = new TextBox(this.driver, by.StockProfile.TotalStockAmount);
			TotalStockAmountA = new TextBox(this.driver, by.StockProfile.AAmount);
			TotalStockAmountB1 = new TextBox(this.driver, by.StockProfile.B1Amount);
			TotalStockAmountB2 = new TextBox(this.driver, by.StockProfile.B2Amount);
			StockRequirementAmount = new TextBox(this.driver, by.StockProfile.StockRequirement);
			StockRequirementExcess = new TextBox(this.driver, by.StockProfile.ExcessStock);
			StockAsOf = new TextBox(this.driver, by.StockProfile.StockAsOf);
			TotalAssets = new TextBox(this.driver, by.StockProfile.TotalAssets);
			MembershipRequirement = new TextBox(this.driver, by.StockProfile.MembershipRequirement);
			MembershipExcessStock = new TextBox(this.driver, by.StockProfile.MembershipExcessStock);
			ActivityRequirement = new TextBox(this.driver, by.StockProfile.ActivityRequirement);
			ActivityRequirementA = new TextBox(this.driver, by.StockProfile.RequiredA);
			ActivityRequirementB = new TextBox(this.driver, by.StockProfile.RequiredB);
			ActivityExcessStock = new TextBox(this.driver, by.StockProfile.ActivityExcessStock);
			ActivityExcessStockA = new TextBox(this.driver, by.StockProfile.ExcessA);
			ActivityExcessStockB = new TextBox(this.driver, by.StockProfile.ExcessB);
			TotalOutstandingRedemption = new TextBox(this.driver, by.StockProfile.TotalOutstandingRedemption);
			InitProfile();
		}
		
		public void InitProfile()
		{
			WebProfile = new Profile();
		}
		
		public class Profile
		{
			public double AAmt = 0;
			public double B1Amt = 0;
			public double B2Amt = 0;
			public double TotStock = 0;
			public double StockReq = 0;
			public double StockReqExcess = 0;
			public Date ProfileDate;
			public double TotAssets = 0;
			public double MembershipReq = 0;
			public double MembershipExcess = 0;
			public double ActivityReq = 0;
			public double ActReqA = 0;
			public double ActReqB = 0;
			public double ActivityExcess = 0;
			public double ActExcessA = 0;
			public double ActExcessB = 0;
			public double OutstandingRedemption = 0;
			
			private MSSQL sql;
			
			public Profile()
			{
				AAmt = TotalStockAmountA.GetValueAsDouble();
				B1Amt = TotalStockAmountB1.GetValueAsDouble();
				B2Amt = TotalStockAmountB2.GetValueAsDouble();
				TotStock = TotalStockAmount.GetValueAsDouble();
				StockReq = StockRequirementAmount.GetValueAsDouble();
				StockReqExcess = StockRequirementExcess.GetValueAsDouble();
				ProfileDate = app.parseDate(StockAsOf.GetValue(), "MM/dd/yyyy");
				TotAssets = TotalAssets.GetValueAsDouble();
				MembershipReq = MembershipRequirement.GetValueAsDouble();
				MembershipExcess = MembershipExcessStock.GetValueAsDouble();
				ActivityReq = ActivityRequirement.GetValueAsDouble();
				ActReqA = ActivityRequirementA.GetValueAsDouble();
				ActReqB = ActivityRequirementB.GetValueAsDouble();
				ActivityExcess = ActivityExcessStock.GetValueAsDouble();
				ActExcessA = ActivityExcessStockA.GetValueAsDouble();
				ActExcessB = ActivityExcessStockB.GetValueAsDouble();
				OutstandingRedemption = TotalOutstandingRedemption.GetValueAsDouble();
			}
			
			public Profile(int BPID, MSSQL sql)
			{
				this.sql = sql;
				Integer StockProfileID = GetMaxStockProfileID(BPID);
				String spSQL = "Select * from dbo.StockProfile"
								+ " Where ID = " + Integer.toString(StockProfileID);
				
				String subSQL = "Select * from dbo.StockProfileSubseriesAmount"
								+ " Where StockProfileID = " + Integer.toString(StockProfileID)
								+ " Order By CapitalStockSubseriesTypeID";
				
				String assetsSQL = "Select * from dbo.TotalAssets t1"
									+ " where t1.BusinessPartnerID = " + Integer.toString(GetBusinessPartnerID(BPID))
									+ " and t1.EffectiveDate = (select max(effectivedate) from dbo.TotalAssets t2 where t1.businesspartnerid = t2.businesspartnerid)";
				
				ResultSet SP = app.getRS(sql, spSQL);
				ResultSet Sub = app.getRS(sql, subSQL);
				ResultSet Assets = app.getRS(sql,  assetsSQL);
				
				try 
				{
					if (SP.next())
					{
						ProfileDate = app.parseDate(SP.getString("EffectiveAsOfDate"), "yyyy-MM-dd");
						
						MembershipReq = SP.getDouble("MembershipRequirementAmountB");
						MembershipExcess = SP.getDouble("MembershipExcessAmountB");
						
						ActReqA = SP.getDouble("ActivityRequiredStockAmountA");
						ActReqB = SP.getDouble("ActivityRequiredStockAmountB");
						
						ActExcessA = SP.getDouble("ActivityExcessStockAmountA");
						ActExcessB = SP.getDouble("ActivityExcessStockAmountB");
						
						OutstandingRedemption = SP.getDouble("OutstandingRedemptionAmountA");
					}
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try 
				{
					if (Assets.next())
					{
						TotAssets = Assets.getDouble("Amount");
					}
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try
				{
					while (Sub.next())
					{
						switch (Sub.getInt("CapitalStockSubseriesTypeID"))
						{
							case 1: B1Amt = Sub.getDouble("Amount"); break;
							case 2: B2Amt = Sub.getDouble("Amount"); break;
							case 3: AAmt = Sub.getDouble("Amount"); break;
						}
					}
					
					TotStock = B1Amt + B2Amt + AAmt;
					ActivityReq = ActReqA + ActReqB;
					ActivityExcess = ActExcessA + ActExcessB;
					
					if (MembershipReq > ActReqB) 
						{ StockReq = MembershipReq; StockReqExcess = MembershipExcess; }
					else 
						{ StockReq = ActivityReq; StockReqExcess = ActivityExcess; }
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			private Integer GetMaxStockProfileID(int BPID)
			{
				String SQL = "select max(ID) MaxID from dbo.StockProfile where BusinessPartnerID = " + Integer.toString(GetBusinessPartnerID(BPID));
				return app.getInt(app.getRS(sql, SQL), "MaxID");
			}
			
			private Integer GetBusinessPartnerID(int BPID)
			{
				String SQL = "select BusinessPartnerID from IfsBusinessPartner where BP_ID = " + Integer.toString(BPID);
				return app.getInt(app.getRS(sql, SQL), "BusinessPartnerID");
			}
		}
		
		public boolean ValidateStockProfile(int BPID)
		{
			Profile DBProfile = new Profile(BPID, this.sql);
			boolean result = true;
			Double.toString(WebProfile.AAmt);
			
			if (WebProfile.AAmt != DBProfile.AAmt) 
			{ 
				result = false; 
				System.out.println("Web AAmt: " + Double.toString(WebProfile.AAmt)); 
				System.out.println("DB AAmt: " + Double.toString(DBProfile.AAmt)); 
			}
			if (WebProfile.B1Amt != DBProfile.B1Amt) 
			{ 
				result = false; 
				System.out.println("Web B1Amt: " + Double.toString(WebProfile.B1Amt)); 
				System.out.println("DB B1Amt: " + Double.toString(DBProfile.B1Amt)); 
			}
			if (WebProfile.B2Amt != DBProfile.B2Amt) 
			{ 
				result = false; 
				System.out.println("Web B2Amt: " + Double.toString(WebProfile.B2Amt)); 
				System.out.println("DB B2Amt: " + Double.toString(DBProfile.B2Amt)); 
			}
			if (WebProfile.TotStock != DBProfile.TotStock) 
			{ 
				result = false; 
				System.out.println("Web TotStock: " + Double.toString(WebProfile.TotStock)); 
				System.out.println("DB TotStock: " + Double.toString(DBProfile.TotStock)); 
			}
			if (WebProfile.StockReq != DBProfile.StockReq) 
			{ 
				result = false; 
				System.out.println("Web StockReq: " + Double.toString(WebProfile.StockReq)); 
				System.out.println("DB STockReq: " + Double.toString(DBProfile.StockReq)); 
			}
			if (WebProfile.StockReqExcess != DBProfile.StockReqExcess) 
			{ 
				result = false; 
				System.out.println("Web StockReqExcess: " + Double.toString(WebProfile.StockReqExcess)); 
				System.out.println("DB StockReqExcess: " + Double.toString(DBProfile.StockReqExcess)); }
			if (WebProfile.ProfileDate.compareTo(DBProfile.ProfileDate) != 0) 
			{ 
				result = false; 
				System.out.println("Web ProfileDate: " + WebProfile.ProfileDate.toString()); 
				System.out.println("DB ProfileDate: " + DBProfile.ProfileDate.toString()); 
			}
			if (WebProfile.TotAssets != DBProfile.TotAssets) 
			{ 
				result = false; 
				System.out.println("Web TotAssets: " + Double.toString(WebProfile.TotAssets)); 
				System.out.println("DB TotAssets: " + Double.toString(DBProfile.TotAssets)); 
			}
			if (WebProfile.MembershipReq != DBProfile.MembershipReq) 
			{ 
				result = false; 
				System.out.println("Web MembershipReq: " + Double.toString(WebProfile.MembershipReq)); 
				System.out.println("DB MembershipReq: " + Double.toString(DBProfile.MembershipReq)); 
			}
			if (WebProfile.MembershipExcess != DBProfile.MembershipExcess) 
			{ 
				result = false; 
				System.out.println("Web MembershipExcess: " + Double.toString(WebProfile.MembershipExcess)); 
				System.out.println("DB MembershipExcess: " + Double.toString(DBProfile.MembershipExcess)); 
			}
			if (WebProfile.ActivityReq != DBProfile.ActivityReq) 
			{ 
				result = false; 
				System.out.println("Web ActivityReq: " + Double.toString(WebProfile.ActivityReq)); 
				System.out.println("DB ActivityReq: " + Double.toString(DBProfile.ActivityReq)); 
			}
			if (WebProfile.ActReqA != DBProfile.ActReqA) 
			{ 
				result = false; 
				System.out.println("Web ActReqA: " + Double.toString(WebProfile.ActReqA)); 
				System.out.println("DB ActReqA: " + Double.toString(DBProfile.ActReqA)); 
			}
			if (WebProfile.ActReqB != DBProfile.ActReqB) 
			{ 
				result = false; 
				System.out.println("Web ActReqB: " + Double.toString(WebProfile.ActReqB)); 
				System.out.println("DB ActReqB: " + Double.toString(DBProfile.ActReqB)); 
			}
			if (WebProfile.ActivityExcess != DBProfile.ActivityExcess) 
			{ 
				result = false; 
				System.out.println("Web ActivityExcess: " + Double.toString(WebProfile.ActivityExcess)); 
				System.out.println("DB ActivityExcess: " + Double.toString(DBProfile.ActivityExcess)); 
			}
			if (WebProfile.ActExcessA != DBProfile.ActExcessA) 
			{ 
				result = false; 
				System.out.println("Web ActExcessA: " + Double.toString(WebProfile.ActExcessA)); 
				System.out.println("DB ActExcessA: " + Double.toString(DBProfile.ActExcessA)); 
			}
			if (WebProfile.ActExcessB != DBProfile.ActExcessB) 
			{ 
				result = false; 
				System.out.println("Web ActExcessB: " + Double.toString(WebProfile.ActExcessB)); 
				System.out.println("DB ActExcessB: " + Double.toString(DBProfile.ActExcessB)); 
			}
			if (WebProfile.OutstandingRedemption != DBProfile.OutstandingRedemption) 
			{ 
				result = false; 
				System.out.println("Web OutstandingRedemption: " + Double.toString(WebProfile.OutstandingRedemption)); 
				System.out.println("DB OutstandingRedemption: " + Double.toString(DBProfile.OutstandingRedemption)); 
			}

			
			return result;
		}
	}
	
	public class StockCalculator
	{
		WebDriver driver;
		
		public Button ViewShareholderStockCapacity;
		public TextBox StockAmount;
		public TextBox NumberOfShares;
		public TextBox ProjectedA;
		public TextBox ProjectedB1;
		public TextBox ProjectedB2;
		
		public StockCalculator(WebDriver driver)
		{
			this.driver = driver;
			ViewShareholderStockCapacity = new Button(this.driver, by.StockCalculator.ViewShareholderStockCapacity);
			StockAmount = new TextBox(this.driver, by.StockCalculator.StockAmount);
			NumberOfShares = new TextBox(this.driver, by.StockCalculator.NumberOfShares);
			ProjectedA = new TextBox(this.driver, by.StockCalculator.ProjectedA);
			ProjectedB1 = new TextBox(this.driver, by.StockCalculator.ProjectedB1);
			ProjectedB2 = new TextBox(this.driver, by.StockCalculator.ProjectedB2);
		}
	}
	
	public class Terms
	{	
		WebDriver driver;
		
		public Purchase purchaseType;
		public Repurchase repurchaseType;
		public Redemption redemptionType;
		public Cancellation cancellationType;
		public StockConversion stockConversionType;
		public StockClass stockClass;
		public RequestedBy requestedBy;
		public Account account;
		public FeeType feeType;
		
		public DateControl DateControl;
		
		public TextBox AmountTo;
		public TextBox NoticeDate;
		public Button NoticeDateButton;
		public TextBox EffectiveDate;
		public Button EffectiveDateButton;
		public TextBox FundingDate;
		public Button FundingDateButton;
		public TextBox Notes;
		public TextBox Fee;
		public Button LIFO;
		public Button Process;
		public Button Cancel;
		
		
		public Terms(WebDriver driver)
		{
			this.driver = driver;
			
			AmountTo = new TextBox(driver, by.Terms.AmountTo);
			NoticeDate = new TextBox(driver, by.Terms.NoticeDate);
			NoticeDateButton = new Button(driver, by.Terms.NoticeDateButton);
			EffectiveDate = new TextBox(driver, by.Terms.EffectiveDate);
			EffectiveDateButton = new Button(driver, by.Terms.EffectiveDateButton);
			FundingDate = new TextBox(driver, by.Terms.FundingDate);
			FundingDateButton = new Button(driver, by.Terms.FundingDateButton);
			Notes = new TextBox(this.driver, by.Terms.Notes);
			Fee = new TextBox(this.driver, by.Terms.Fee);
			LIFO = new Button(this.driver, by.Terms.LIFO);
			Process = new Button(this.driver, by.Terms.Process);
			Cancel = new Button(this.driver, by.Terms.Cancel);
			purchaseType = new Purchase(this.driver, by.Terms.TransactionType);
			repurchaseType = new Repurchase(this.driver, by.Terms.TransactionType);
			redemptionType = new Redemption(this.driver, by.Terms.TransactionType);
			cancellationType = new Cancellation(this.driver, by.Terms.TransactionType);
			stockConversionType = new StockConversion(this.driver, by.Terms.TransactionType);
			stockClass = new StockClass(this.driver, by.Terms.StockClass);
			requestedBy = new RequestedBy(this.driver, by.Terms.RequestedBy);
			account = new Account(this.driver, by.Terms.Account);
			feeType = new FeeType(this.driver, by.Terms.FeeType);
			DateControl = new DateControl(driver);
		}
		
		public class TransactionType extends DropDown
		{
			
			TransactionType(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetDefault()
			{
				SetByVisibleText("Select...");
			}
		}
		
		public class Purchase extends TransactionType
		{
			public Purchase(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetOriginalStock()
			{
				SetByVisibleText("Original Stock");
			}
			
			public void SetRequiredStock()
			{
				SetByVisibleText("Required Stock");
			}
			
			public void SetVoluntaryStock()
			{
				SetByVisibleText("Voluntary Stock");
			}
		}
		
		public class Repurchase extends TransactionType
		{
			public Repurchase(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetStockDividend()
			{
				SetByVisibleText("Stock Dividend");
			}
			
			public void SetFHLBIExcessStock()
			{
				SetByVisibleText("FHLBI Excess Stock");
			}
			
			public void SetMemberExcessStock()
			{
				SetByVisibleText("MemberExcessStock");
			}
		}
		
		public class Redemption extends TransactionType
		{
			public Redemption(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetStockRedemption()
			{
				SetByVisibleText("Stock Redemption");
			}
			
			public void SetRelocation()
			{
				SetByVisibleText("Relocation");
			}
			
			public void SetTermination()
			{
				SetByVisibleText("Termination");
			}
			
			public void SetWithdrawal()
			{
				SetByVisibleText("Withdrawal");
			}
		}
		
		public class Cancellation extends TransactionType
		{
			public Cancellation(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetCancelRepurchase()
			{
				SetByVisibleText("Cancel Repurchase");
			}
			
			public void SetCancelRedemption()
			{
				SetByVisibleText("Cancel Redemption");
			}
			
			public void SetCancelWithdrawal()
			{
				SetByVisibleText("Cancel Withdrawal");
			}
			
			public void SetCancelRelocation()
			{
				SetByVisibleText("Cancel Relocation");
			}
			
			public void SetCancelTermination()
			{
				SetByVisibleText("Cancel Termination");
			}
		}
		
		public class StockConversion extends TransactionType
		{
			public StockConversion(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetConvertAtoB()
			{
				SetByVisibleText("Convert A to B");
			}
			
			public void SetConvertBtoA()
			{
				SetByVisibleText("Convert B to A");
			}			
		}
		
		public class StockClass extends DropDown
		{
			public StockClass(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetDefault()
			{
				SetByVisibleText("Select...");
			}
			
			public void SetOriginalStock()
			{
				SetByVisibleText("Class A");
			}
			
			public void SetRequiredStock()
			{
				SetByVisibleText("Class B");
			}
		}
		
		public class RequestedBy extends DropDown
		{
			public RequestedBy(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetDefault()
			{
				SetByVisibleText("Select...");
			}
		}

		public class Account extends DropDown
		{
			public Account(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetDefault()
			{
				SetByVisibleText("Select...");
			}
			
			public void SetCheck()
			{
				SetByVisibleText("Check");
			}
			
			public void SetCMS()
			{
				SetByVisibleText("CMS");
			}
			
			public void SetTime()
			{
				SetByVisibleText("Time");
			}
			
			public void SetWire()
			{
				SetByVisibleText("Wire");
			}
		}
		
		public class FeeType extends DropDown
		{
			public FeeType(WebDriver driver, By by)
			{
				super(driver, by);
			}
			
			public void SetDefault()
			{
				SetByVisibleText("Select...");
			}
			
			public void SetManualEntry()
			{
				SetByVisibleText("Cancellation Fee Manual Entry");
			}
		}
	}
	
	public class StockTransactionTable
	{	
		WebDriver driver;
		
		public List<Transaction> Transactions = new ArrayList<Transaction>();
		
		public StockTransactionTable(WebDriver driver)
		{
			this.driver = driver;
		}
		
		public class Transaction
		{
			WebDriver driver;
			public int ItemID;
			public Date AcquiredDate;
			public String TransactionType;
			public String StockClass;
			public int OriginalStockAmount;
			public int TransactionsFunded;
			public int TransactionsPending;
			public int AvailableAmount;
			public TextBox AmountOf;
			
			public Transaction(WebElement row, WebDriver driver)
			{
				this.driver = driver;
				ItemID = Integer.parseInt(row.getAttribute("lineitemid"));
				AcquiredDate = app.parseDate(row.findElement(by.StockTransactionTable.Transaction.AcquiredDate).getText(), "MM/dd/yyyy");
				TransactionType = row.findElement(by.StockTransactionTable.Transaction.TransactionType).getText();
				StockClass = row.findElement(by.StockTransactionTable.Transaction.StockClass).getText();
				OriginalStockAmount = Integer.parseInt(row.findElement(by.StockTransactionTable.Transaction.OriginalStockAmount).getText());
				TransactionsFunded = Integer.parseInt(row.findElement(by.StockTransactionTable.Transaction.TransactionsFunded).getText());
				TransactionsPending = Integer.parseInt(row.findElement(by.StockTransactionTable.Transaction.TransactionsPending).getText());
				AvailableAmount = Integer.parseInt(row.findElement(by.StockTransactionTable.Transaction.AvailableAmount).getText());
				AmountOf = new TextBox(row, this.driver, by.StockTransactionTable.Transaction.AmountOf);
			}
		}
	
		public void populateTransactions()
		{
			Transactions.clear();
			
			for (WebElement row : driver.findElements(by.StockTransactionTable.TableRows))
			{
				Transactions.add(new Transaction(row, this.driver));
			}
		}
	}
}
