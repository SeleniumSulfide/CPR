package CapStock;

import org.openqa.selenium.WebDriver;

import ByRepo.HeaderByRepo;
import util.BaseControls.Label;
import util.BaseControls.Link;;

public class Header 
{
	WebDriver driver;
	
	public HeaderByRepo by = new HeaderByRepo();
	public SysInfo sysInfo;
	public NavBar navBar;
	public App app;
	
	public Header(WebDriver driver)
	{
		this.driver = driver;
		sysInfo = new SysInfo(this.driver);
		navBar = new NavBar(this.driver);
		app = new App(this.driver);
	}
	
	public class SysInfo
	{
		WebDriver driver;
		
		public Label SystemDate;
		public Label Environment;
		public Label CurrentUser;
		
		public SysInfo (WebDriver driver)
		{
			this.driver = driver;
			SystemDate = new Label(this.driver, by.sysInfo.SysDate);
			Environment = new Label(this.driver, by.sysInfo.Environment);
			CurrentUser = new Label(this.driver, by.sysInfo.CurrentUser);
		}
	}
	
	public class NavBar
	{
		WebDriver driver;
		
		public Link Home;
		public Link Transactions;
		public Link Reports;
		public Link Administration;
		
		public TransactionMenu transactionMenu;
		public ReportsMenu reportsMenu;
		public AdministrationMenu administrationMenu;
		
		public class TransactionMenu
		{
			WebDriver driver;
			
			public Link Purchase;
			public Link Repurchase;
			public Link Redemption;
			public Link Cancellation;
			public Link StockConversion;
			public Link DividendProjection;
			public Link Transfer;
			public Link Merger;
			public Link TransactionMaintenance;
			public Link TransactionBackdating;
			public Link TransactionApproval;
			public Link MassRepurchase;
			
			public TransactionMenu(WebDriver driver)
			{
				this.driver = driver;
				Purchase = new Link(this.driver, by.navBar.transactionMenu.Purchase);
				Repurchase = new Link(this.driver, by.navBar.transactionMenu.Repurchase);
				Redemption = new Link(this.driver, by.navBar.transactionMenu.Redemption);
				Cancellation = new Link(this.driver, by.navBar.transactionMenu.Cancellation);
				StockConversion = new Link(this.driver, by.navBar.transactionMenu.StockConversion);
				DividendProjection = new Link(this.driver, by.navBar.transactionMenu.DividendProjection);
				Transfer = new Link(this.driver, by.navBar.transactionMenu.Transfer);
				Merger = new Link(this.driver, by.navBar.transactionMenu.Merger);
				TransactionMaintenance = new Link(this.driver, by.navBar.transactionMenu.TransactionMaintenance);
				TransactionBackdating = new Link(this.driver, by.navBar.transactionMenu.TransactionBackdating);
				TransactionApproval = new Link(this.driver, by.navBar.transactionMenu.TransactionApproval);
				MassRepurchase = new Link(this.driver, by.navBar.transactionMenu.MassRepurchase);
			}
			
			public void  ClickPurchase() { app.HoverClick(Transactions.GetElement(), Purchase.GetElement()); }
			public void  ClickRepurchase() { app.HoverClick(Transactions.GetElement(), Repurchase.GetElement()); }
			public void  ClickRedemption() { app.HoverClick(Transactions.GetElement(), Redemption.GetElement()); }
			public void  ClickCancellation() { app.HoverClick(Transactions.GetElement(), Cancellation.GetElement()); }
			public void  ClickStockConversion() { app.HoverClick(Transactions.GetElement(), StockConversion.GetElement()); }
			public void  ClickDividendProjection() { app.HoverClick(Transactions.GetElement(), DividendProjection.GetElement()); }
			public void  ClickTransfer() { app.HoverClick(Transactions.GetElement(), Transfer.GetElement()); }
			public void  ClickMerger() { app.HoverClick(Transactions.GetElement(), Merger.GetElement()); }
			public void  ClickTransactionMaintenance() { app.HoverClick(Transactions.GetElement(), TransactionMaintenance.GetElement()); }
			public void  ClickTransactionBackdating() { app.HoverClick(Transactions.GetElement(), TransactionBackdating.GetElement()); }
			public void  ClickTransactionApproval() { app.HoverClick(Transactions.GetElement(), TransactionApproval.GetElement()); }
			public void  ClickMassRepurchase() { app.HoverClick(Transactions.GetElement(), MassRepurchase.GetElement()); }

		}
		
		public class ReportsMenu
		{
			WebDriver driver;
			
			public Link OutstandingRedemptionsReport;
			public Link CapitalStockNegativeExcessReport;
			public Link CapitalStockTransactionsReport;
			public Link CapitalStockTransactionsActivityReport;
			public Link CapitalStockJournalEntriesReport;
			public Link CapitalStockTransactionsByMemberReport;
			public Link CapitalStockBalanceReport;
			public Link CapitalStockBalanceDetailsReport;
			public Link CapitalStockDividendsReport;
			public Link CapitalStockTransactionHistory;
			public Link VotingSharesReport;
			public Link StockPercentageReport;
			public Link CapitalStockProfileActivityReport;
			public Link CapitalStockTrialBalance;
			public Link CapitalStockActivityRollforwardReport;
			public Link CapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption;
			public Link FAS150InterestExpenseReport;
			public Link AMADetails;
			public Link AMAToday;
			public Link MemberDividendHistoryReport;
			public Link PendingTransactionsReport;
			public Link CreditProductsDetail;
			public Link CapitalStockBackdatedTransactionReport;
			public Link CapitalStockAllShareholderSharesReport;

			public ReportsMenu(WebDriver driver)
			{
				this.driver = driver;
				OutstandingRedemptionsReport = new Link(this.driver, by.navBar.reportsMenu.OutstandingRedemptionsReport);
				CapitalStockNegativeExcessReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockNegativeExcessReport);
				CapitalStockTransactionsReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockTransactionsReport);
				CapitalStockTransactionsActivityReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockTransactionsActivityReport);
				CapitalStockJournalEntriesReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockJournalEntriesReport);
				CapitalStockTransactionsByMemberReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockTransactionsByMemberReport);
				CapitalStockBalanceReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockBalanceReport);
				CapitalStockBalanceDetailsReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockBalanceDetailsReport);
				CapitalStockDividendsReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockDividendsReport);
				CapitalStockTransactionHistory = new Link(this.driver, by.navBar.reportsMenu.CapitalStockTransactionHistory);
				VotingSharesReport = new Link(this.driver, by.navBar.reportsMenu.VotingSharesReport);
				StockPercentageReport = new Link(this.driver, by.navBar.reportsMenu.StockPercentageReport);
				CapitalStockProfileActivityReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockProfileActivityReport);
				CapitalStockTrialBalance = new Link(this.driver, by.navBar.reportsMenu.CapitalStockTrialBalance);
				CapitalStockActivityRollforwardReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockActivityRollforwardReport);
				CapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption = new Link(this.driver, by.navBar.reportsMenu.CapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption);
				FAS150InterestExpenseReport = new Link(this.driver, by.navBar.reportsMenu.FAS150InterestExpenseReport);
				AMADetails = new Link(this.driver, by.navBar.reportsMenu.AMADetails);
				AMAToday = new Link(this.driver, by.navBar.reportsMenu.AMAToday);
				MemberDividendHistoryReport = new Link(this.driver, by.navBar.reportsMenu.MemberDividendHistoryReport);
				PendingTransactionsReport = new Link(this.driver, by.navBar.reportsMenu.PendingTransactionsReport);
				CreditProductsDetail = new Link(this.driver, by.navBar.reportsMenu.CreditProductsDetail);
				CapitalStockBackdatedTransactionReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockBackdatedTransactionReport);
				CapitalStockAllShareholderSharesReport = new Link(this.driver, by.navBar.reportsMenu.CapitalStockAllShareholderSharesReport);
			}

			public int xOffset = 0;
			public int yOffset = 29;
			public void ClickOutstandingRedemptionsReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, OutstandingRedemptionsReport.GetElement()); }
			public void ClickCapitalStockNegativeExcessReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockNegativeExcessReport.GetElement()); }
			public void ClickCapitalStockTransactionsReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockTransactionsReport.GetElement()); }
			public void ClickCapitalStockTransactionsActivityReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockTransactionsActivityReport.GetElement()); }
			public void ClickCapitalStockJournalEntriesReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockJournalEntriesReport.GetElement()); }
			public void ClickCapitalStockTransactionsByMemberReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockTransactionsByMemberReport.GetElement()); }
			public void ClickCapitalStockBalanceReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockBalanceReport.GetElement()); }
			public void ClickCapitalStockBalanceDetailsReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockBalanceDetailsReport.GetElement()); }
			public void ClickCapitalStockDividendsReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockDividendsReport.GetElement()); }
			public void ClickCapitalStockTransactionHistory() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockTransactionHistory.GetElement()); }
			public void ClickVotingSharesReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, VotingSharesReport.GetElement()); }
			public void ClickStockPercentageReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, StockPercentageReport.GetElement()); }
			public void ClickCapitalStockProfileActivityReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockProfileActivityReport.GetElement()); }
			public void ClickCapitalStockTrialBalance() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockTrialBalance.GetElement()); }
			public void ClickCapitalStockActivityRollforwardReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockActivityRollforwardReport.GetElement()); }
			public void ClickCapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockTrialBalanceMemberConcentrationandExcessStockSubjecttoRedemption.GetElement()); }
			public void ClickFAS150InterestExpenseReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, FAS150InterestExpenseReport.GetElement()); }
			public void ClickAMADetails() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, AMADetails.GetElement()); }
			public void ClickAMAToday() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, AMAToday.GetElement()); }
			public void ClickMemberDividendHistoryReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, MemberDividendHistoryReport.GetElement()); }
			public void ClickPendingTransactionsReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, PendingTransactionsReport.GetElement()); }
			public void ClickCreditProductsDetail() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CreditProductsDetail.GetElement()); }
			public void ClickCapitalStockBackdatedTransactionReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockBackdatedTransactionReport.GetElement()); }
			public void ClickCapitalStockAllShareholderSharesReport() { app.HoverClick(Reports.GetElement(), xOffset, yOffset, CapitalStockAllShareholderSharesReport.GetElement()); }
		}
		
		public class AdministrationMenu
		{
			WebDriver driver;
			
			public Link GlobalSettings;
			public Link StockTransactionBlackout;
			public Link StockRequirementSettings;
			public Link TransactionDenialPeriods;
			public Link AccountingAdministration;
			public Link ClassAStockSettings;
			public Link TotalAssetsLoadSetup;
			
			public AdministrationMenu(WebDriver driver)
			{
				this.driver = driver;
				GlobalSettings = new Link(this.driver, by.navBar.administrationMenu.GlobalSettings);
				StockTransactionBlackout = new Link(this.driver, by.navBar.administrationMenu.StockTransactionBlackout);
				StockRequirementSettings = new Link(this.driver, by.navBar.administrationMenu.StockRequirementSettings);
				TransactionDenialPeriods = new Link(this.driver, by.navBar.administrationMenu.TransactionDenialPeriods);
				AccountingAdministration = new Link(this.driver, by.navBar.administrationMenu.AccountingAdministration);
				ClassAStockSettings = new Link(this.driver, by.navBar.administrationMenu.ClassAStockSettings);
				TotalAssetsLoadSetup = new Link(this.driver, by.navBar.administrationMenu.TotalAssetsLoadSetup);
			}
			
			public void ClickGlobalSettings() { app.HoverClick(Administration.GetElement(), GlobalSettings.GetElement()); }
			public void ClickStockTransactionBlackout() { app.HoverClick(Administration.GetElement(), StockTransactionBlackout.GetElement()); }
			public void ClickStockRequirementSettings() { app.HoverClick(Administration.GetElement(), StockRequirementSettings.GetElement()); }
			public void ClickTransactionDenialPeriods() { app.HoverClick(Administration.GetElement(), TransactionDenialPeriods.GetElement()); }
			public void ClickAccountingAdministration() { app.HoverClick(Administration.GetElement(), AccountingAdministration.GetElement()); }
			public void ClickClassAStockSettings() { app.HoverClick(Administration.GetElement(), ClassAStockSettings.GetElement()); }
			public void ClickTotalAssetsLoadSetup() { app.HoverClick(Administration.GetElement(), TotalAssetsLoadSetup.GetElement()); }

		}
		
		public NavBar(WebDriver driver)
		{
			this.driver = driver;
			Home = new Link(this.driver, by.navBar.Home);
			Transactions = new Link(this.driver, by.navBar.Transactions);
			Reports = new Link(this.driver, by.navBar.Reports);
			Administration = new Link(this.driver, by.navBar.Administration);
			transactionMenu = new TransactionMenu(this.driver);
			reportsMenu = new ReportsMenu(this.driver);
			administrationMenu = new AdministrationMenu(this.driver);
		}
	}
}
