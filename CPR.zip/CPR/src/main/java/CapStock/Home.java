package CapStock;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ByRepo.HomeByRepo;

import CapStock.Header;
import util.BaseControls.Button;
import util.BaseControls.Label;
import util.BaseControls.TextBox;
import util.ExtendedControls.SearchResult;

public class Home 
{
	WebDriver driver;
	App app;
	
	public Header header;
	public HomeByRepo by = new HomeByRepo();
	
	public TextBox SearchCriteria; 
	public Button Search;
	public ResultsGrid ResultsGrid;
	
	public class ResultsGrid
	{
		WebDriver driver;
		App app;
		public Label NoResults;
		
		public List<SearchResult> SearchResults = new ArrayList<SearchResult>();
		
		public ResultsGrid(WebDriver driver) 
		{ 
			this.driver = driver;
			NoResults = new Label(this.driver, by.resultsGrid.NoResults);
			app = new App(this.driver);
		};
		
		public void populateSearchResults()
		{
			SearchResults.clear();
			
			for (WebElement row : driver.findElements(by.resultsGrid.TableRows))
			{
				SearchResult sr = new SearchResult(row, this.driver);
				SearchResults.add(sr);
			}
		}
		
		public SearchResult getResult(int BPID)
		{
			for (SearchResult result : SearchResults)
			{
				if (result.BPID == BPID) { return result; }
			}
			
			return null;
		}
		
		public SearchResult getResult(String Name)
		{
			for (SearchResult result : SearchResults)
			{
				if (result.Name.GetElement().getText() == Name) { return result; }
			}
			
			return null;			
		}
	
		public Boolean checkResultExists(int BPID)
		{
			by.resultsGrid.BPID = By.xpath("//td[text()='[BPID]']".replace("[BPID]", String.valueOf(BPID)));
			return app.fluentWaitForElementLocated(by.resultsGrid.BPID);
		}
		
		public Boolean checkResultExists(String Name)
		{
			by.resultsGrid.Name = By.xpath("//a[text()='[NAME]']".replace("[NAME]", Name));
			return app.fluentWaitForElementLocated(by.resultsGrid.Name);
		}
	}

	public Home(WebDriver driver)
	{
		this.driver = driver;
		SearchCriteria = new TextBox(this.driver, by.SearchCriteria);
		Search = new Button(this.driver, by.Search);
		ResultsGrid = new ResultsGrid(this.driver);
		header = new Header(this.driver);
		app = new App(this.driver);
	}

	
	public void SearchForMember(int BPID)
	{
		SearchCriteria.Clear();
		SearchCriteria.SendKeys(String.valueOf(BPID));
		Search.Click();
		app.waitForReadyStateComplete();
	}
	
	public void SearchForMember(String Name)
	{
		SearchCriteria.Clear();
		SearchCriteria.SendKeys(Name);
		Search.Click();
	}
	
	public void NavigateDefault(int BPID)
	{
		ResultsGrid.populateSearchResults();
		SearchResult sr = ResultsGrid.getResult(BPID);
		sr.TransactionType.SetDefault();
		sr.EnterTransaction.Click();
	}
	
	public void NavigatePurchase(int BPID)
	{
		ResultsGrid.populateSearchResults();
		SearchResult sr = ResultsGrid.getResult(BPID);
		sr.TransactionType.SetPurchase();
		sr.EnterTransaction.Click();
	}
	
	public void NavigateRepurchase(int BPID)
	{
		ResultsGrid.populateSearchResults();
		SearchResult sr = ResultsGrid.getResult(BPID);
		sr.TransactionType.SetRepurchase();
		sr.EnterTransaction.Click();
	}
	
	public void NavigateRedemption(int BPID)
	{
		ResultsGrid.populateSearchResults();
		SearchResult sr = ResultsGrid.getResult(BPID);
		sr.TransactionType.SetRedemption();
		sr.EnterTransaction.Click();
	}
	
	public void NavigateCancellation(int BPID)
	{
		ResultsGrid.populateSearchResults();
		SearchResult sr = ResultsGrid.getResult(BPID);
		sr.TransactionType.SetCancellation();
		sr.EnterTransaction.Click();
	}
	
	public void NavigateStockConversion(int BPID)
	{
		ResultsGrid.populateSearchResults();
		SearchResult sr = ResultsGrid.getResult(BPID);
		sr.TransactionType.SetStockConversion();
		sr.EnterTransaction.Click();
	}
}
